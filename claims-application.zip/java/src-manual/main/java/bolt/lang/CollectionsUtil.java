package bolt.lang;

import java.util.List;

import org.springframework.stereotype.Component;
@Component
public class CollectionsUtil {

	public <T> Boolean add(List<T> list, T object) {
		return list.add(object);		
	}

}
