package app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;


import org.apache.catalina.connector.Connector;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.beans.factory.annotation.Value;
@SpringBootApplication (scanBasePackages = {
"superbolt.util.dao",

"bolt.lang","core.services"
})
@EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
public class Claims {

	@Value("${ajpPort}") protected Integer ajpPort;
	
	public static void main(String[] args) {
		SpringApplication.run(Claims.class, args);
	}

	@Bean
	 public WebServerFactoryCustomizer<TomcatServletWebServerFactory> servletContainer() {
	   return server -> {
	     if (server instanceof TomcatServletWebServerFactory) {
	         ((TomcatServletWebServerFactory) server).addAdditionalTomcatConnectors(redirectConnector());
	     }
	   };
	 }

    private Connector redirectConnector() {
       Connector connector = new Connector("AJP/1.3");
       connector.setScheme("https");
       connector.setPort(ajpPort);
       connector.setSecure(false);
       connector.setAllowTrace(false);
       return connector;
    }		
}
