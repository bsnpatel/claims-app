
export interface ClaimLine {
	isDirty: boolean;
	revenueCd : string;
	modifierCd1 : string;
	modifierCd2 : string;
	modifierCd3 : string;
	modifierCd4 : string;
	lineCharge : string;
	procedureCd : string;
	diagPointer : string;
	lineNo : number;
	id : string;
	units : number;
	ndcCode : string;
	ndcUnits : number;
	placeOfService : string;
	ndcUnitType : string;
}
