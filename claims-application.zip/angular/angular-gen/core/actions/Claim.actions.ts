import {Action} from '@ngrx/store';
import {Update} from '@ngrx/entity';
import {Claim} from '../models/Claim.model';

export enum ClaimActionTypes {
	LoadClaims = '[Claim] Load Claims',
	LoadClaim = '[Claim] Load Claim',
	ClaimLoaded = '[Claim]  Claim Loaded',
	AllClaimLoaded = '[Claim] All Claims Loaded',
	AllClaimLoadFailed = '[Claim] Load All Claims Failed',
	LoadClaimsByParentId = '[Claim] Load Claims By ParentId',
	AllClaimByParentIdLoaded = '[Claim] All Claims By ParentId Loaded',
	AllClaimByParentIdLoadFailed = '[Claim] Load All Claims By ParentId Failed',
	UpdateClaimUiState = '[Claim] Update ui state',
	AddClaim = '[Claim] Add Claim',
	UpsertClaim = '[Claim] Upsert Claim',
	AddClaims = '[Claim] Add Claims',
	UpsertClaims = '[Claim] Upsert Claims',
	UpdateClaim = '[Claim] Update Claim',
	UpdateClaimSuccess =   '[Claim] Update Claim Success',
	UpdateClaimFail =   '[Claim] Update Claim Fail',
	UpdateClaims = '[Claim] Update Claims',
	DeleteClaim = '[Claim] Delete Claim',
	DeleteClaimSuccess = '[Claim] Delete Claim Success',
	DeleteClaimFail = '[Claim] Delete Claim Fail',
	DeleteClaims = '[Claim] Delete Claims',
	ClearClaims = '[Claim] Clear Claims',
	ResetClaim = '[Claim] Reset Claim',
	ReloadClaim = '[Claim] Reload Claim',
	SelectClaim = '[Claim] Select Claim',
	SelectClaimById= '[Claim] Select Claim By Id',
	ResetClaimErrorState = '[Claim] Reset Claim Error State',
	NoAction = '[Claim] No Action'
	
}

export class UpdateClaimUiState implements Action {
	readonly type = ClaimActionTypes.UpdateClaimUiState;
	constructor(public payload: { uiState: string }) {
	}
}

export class ClaimLoaded implements Action {
	readonly type = ClaimActionTypes.ClaimLoaded;
	constructor(public payload: { claim: Claim }) {
	}
}

export class AllClaimLoaded implements Action {
	readonly type = ClaimActionTypes.AllClaimLoaded;
	constructor(public payload: { claims: Claim[] }) {
	}
}

export class AllClaimLoadFailed implements Action {
	readonly type = ClaimActionTypes.AllClaimLoadFailed;
	constructor(public payload: { error: Error }) {
	}
}

export class AllClaimByParentIdLoaded implements Action {
	readonly type = ClaimActionTypes.AllClaimByParentIdLoaded;
	constructor(public payload: { claims: Claim[] }) {
	}
}

export class AllClaimByParentIdLoadFailed implements Action {
	readonly type = ClaimActionTypes.AllClaimByParentIdLoadFailed;
	constructor(public payload: { error: Error }) {
	}
}				
export class LoadClaim implements Action {
	readonly type = ClaimActionTypes.LoadClaim;
	constructor(public payload: { claim: string }) {
	}
}

export class  ResetClaimErrorState implements Action {
	readonly type = ClaimActionTypes.ResetClaimErrorState;
	constructor() {
	}
}

export class LoadClaims implements Action {
	readonly type = ClaimActionTypes.LoadClaims;
	constructor() {
	}
}

export class LoadClaimsByParentId implements Action {
	readonly type = ClaimActionTypes.LoadClaimsByParentId;
	constructor(public payload: {parentId : string} ) {
	}
}

export class AddClaim implements Action {
	readonly type = ClaimActionTypes.AddClaim;
	constructor(public payload: { claim: Claim}) {
	}
}

export class UpsertClaim implements Action {
	readonly type = ClaimActionTypes.UpsertClaim;
	constructor(public payload: { claim: Claim}) {
	}
}

export class AddClaims implements Action {
	readonly type = ClaimActionTypes.AddClaims;

	constructor(public payload: { claims: Claim[] }) {
	}
}

export class UpsertClaims implements Action {
	readonly type = ClaimActionTypes.UpsertClaims;
	constructor(public payload: { claims: Claim[] }) {
	}
}


export class UpdateClaimSuccess implements Action {
	readonly type = ClaimActionTypes.UpdateClaimSuccess;
	constructor(public payload: { claim: Claim }) {
	}
}
export class UpdateClaimFail implements Action {
	readonly type = ClaimActionTypes.UpdateClaimFail;
	constructor(public payload: { error: Error }) {
	}
}
export class UpdateClaim implements Action {
	readonly type = ClaimActionTypes.UpdateClaim;
	constructor(public payload: { claim: Claim }) {
	}
}

export class UpdateClaims implements Action {
	readonly type = ClaimActionTypes.UpdateClaims;
	constructor(public payload: { claims: Update<Claim>[] }) {
	}
}
				
export class DeleteClaimSuccess implements Action {
	readonly type = ClaimActionTypes.DeleteClaimSuccess;
	constructor(public payload: { id: string }) {
	}
}
export class DeleteClaimFail implements Action {
	readonly type = ClaimActionTypes.DeleteClaimFail;
	constructor(public payload: { error: Error }) {
	}
}

export class DeleteClaim implements Action {
	readonly type = ClaimActionTypes.DeleteClaim;
	constructor(public payload: { id: string }) {
	}
}

export class DeleteClaims implements Action {
	readonly type = ClaimActionTypes.DeleteClaims;
	constructor(public payload: { ids: string[] }) {
	}
}

export class ClearClaims implements Action {
	readonly type = ClaimActionTypes.ClearClaims;
}

export class ResetClaim implements Action {
	readonly type = ClaimActionTypes.ResetClaim;
}

export class SelectClaim implements Action {
	readonly type = ClaimActionTypes.SelectClaim;
	constructor(public payload: { claim: Claim }) {
	}
}

export class ReloadClaim implements Action {
	readonly type = ClaimActionTypes.ReloadClaim;
}

export class SelectClaimById implements Action {
	readonly type = ClaimActionTypes.SelectClaimById;
	constructor(public payload: { id: string }) {
	}
}
export class NoAction implements Action {
	readonly type = ClaimActionTypes.NoAction;
  
	constructor() {
	}
}

	
export type ClaimActions =
	LoadClaims
	| LoadClaimsByParentId
	| AllClaimLoaded
	| AllClaimLoadFailed
	| AllClaimByParentIdLoaded
	| AllClaimByParentIdLoadFailed
	| ClaimLoaded
	| UpdateClaimUiState
	| AddClaim
	| UpsertClaim
	| AddClaims
	| UpsertClaims
	| UpdateClaim
	| UpdateClaimFail
	| UpdateClaimSuccess
	| UpdateClaims
	| DeleteClaim
	| DeleteClaimFail
	| DeleteClaimSuccess
	| DeleteClaims
	| ClearClaims
	| ResetClaim
	| ReloadClaim
	| SelectClaim
	| SelectClaimById
	| ResetClaimErrorState
	| NoAction
	;
