import {createEntityAdapter, EntityAdapter, EntityState} from '@ngrx/entity';
import { deepCopy, extend } from 'src/app/shared/utils';
import {ClaimLine} from '../models/ClaimLine.model';
import {ClaimLineActions, ClaimLineActionTypes} from '../actions/ClaimLine.actions';

export interface ClaimLineState extends EntityState<ClaimLine> {
	// additional entities state properties
	uiState?: string;
	error?: any;
	selected?: ClaimLine;
}

export const adapter: EntityAdapter<ClaimLine> = createEntityAdapter<ClaimLine>();

export const initialState: ClaimLineState = adapter.getInitialState({
	// additional entity state properties
	uiState: '',
	error: '',
	selected: {
	isDirty: false,
	modifierCd1: null,
	modifierCd2: null,
	modifierCd3: null,
	modifierCd4: null,
	lineCharge: null,
	procedureCd: null,
	diagPointer: null,
	lineNo: null,
	id: null,
	units: null,
	revenueCd: null,
	placeOfService: '',
	}
});

export function reducer(state = initialState, action: ClaimLineActions): ClaimLineState {
	switch (action.type) {
		case ClaimLineActionTypes.AddClaimLine: {
			return adapter.addOne(action.payload.claimLine, state);
		}

		case ClaimLineActionTypes.UpsertClaimLine: {
			return adapter.upsertOne(action.payload.claimLine, state);
		}

		case ClaimLineActionTypes.AddClaimLines: {
			return adapter.addMany(action.payload.claimLines, state);
		}

		case ClaimLineActionTypes.UpsertClaimLines: {
			return adapter.upsertMany(action.payload.claimLines, state);
		}

		case ClaimLineActionTypes.UpdateClaimLineUiState: {
			return {...state, uiState: action.payload.uiState, error:''};
		}

		case ClaimLineActionTypes.UpdateClaimLineSuccess: {
			return adapter.upsertOne(action.payload.claimLine, {
				...state,
				uiState: 'updated',
				error:'',
				selected: action.payload.claimLine
			});
		}

		case ClaimLineActionTypes.UpdateClaimLineFail: {
			return {...state, uiState: 'updatefailed',  error: action.payload};
		}

		case ClaimLineActionTypes.UpdateClaimLine: {
			return {...state, uiState: 'updating', error:''};
		}

		case ClaimLineActionTypes.LoadClaimLines: {
			return {...state, uiState: 'loading', error:''};
		}

		case ClaimLineActionTypes.LoadClaimLinesByParentId: {
			return {...state, uiState: 'loading', error:''};
		}

		case ClaimLineActionTypes.UpdateClaimLines: {
			return adapter.updateMany(action.payload.claimLines, state);
		}

		case ClaimLineActionTypes.DeleteClaimLineSuccess: {
			return adapter.removeOne(action.payload.id, {
				...state,
				uiState: 'deleted',
				error:'',
				selected: undefined
			});
		}

		case ClaimLineActionTypes.DeleteClaimLineFail: {
			return {...state, uiState: 'deletefailed',  error: action.payload};
		}

		case ClaimLineActionTypes.DeleteClaimLine: {
			return {...state, uiState: 'deleting', error:''};
		}

		case ClaimLineActionTypes.DeleteClaimLines: {
			return adapter.removeMany(action.payload.ids, state);
		}

		case ClaimLineActionTypes.AllClaimLineLoaded: {
			return adapter.addAll(action.payload.claimLines, {
				...state,
				uiState: 'loaded',
				error:'',
				selected: (state.selected === null || (state.selected !=null && (state.selected.id ===null || state.selected.id=== ''))) ?  action.payload.claimLines[0] : state.selected 
		
				
			});
		}

		case ClaimLineActionTypes.AllClaimLineByParentIdLoaded: {
			return adapter.addAll(action.payload.claimLines, {
				...state,
				uiState: 'loaded',
				error:'',
				selected: action.payload.claimLines[0]
			});
		}

		case ClaimLineActionTypes.ResetClaimLineErrorState:{
			return {...state, error: '', uiState: 'ready'};
		}

		case ClaimLineActionTypes.AllClaimLineLoadFailed: {
			return {...state, uiState: 'loadfailed', error: action.payload};
		}

		case ClaimLineActionTypes.AllClaimLineByParentIdLoadFailed: {
			return {...state, uiState: 'loadfailed', error: action.payload};
		}
				
		case ClaimLineActionTypes.ClaimLineLoaded: {
			return adapter.addOne(action.payload.claimLine, {
								...state,
								uiState: 'loaded',
								error:'',
								selected: action.payload.claimLine
							});
		}

		case ClaimLineActionTypes.ClearClaimLines: {
			return adapter.removeAll(state);
		}

		case ClaimLineActionTypes.ReloadClaimLine: {
			return {...initialState, selected: initialState.selected, uiState:'', error:''};
		}
		
		case ClaimLineActionTypes.ResetClaimLine: {
			return {...state, selected: initialState.selected, uiState:'ready', error:''};
		}

		
		case ClaimLineActionTypes.SelectClaimLine: {
			return {...state, selected: action.payload.claimLine};
		}

	   case ClaimLineActionTypes.SelectClaimLineById: {
	     return {...state, selected: state.entities[action.payload.id]};
	   }

		default: {
			return state;
		}
	}
}


export const {
	selectIds,
	selectEntities,
	selectAll,
	selectTotal,
} = adapter.getSelectors();
