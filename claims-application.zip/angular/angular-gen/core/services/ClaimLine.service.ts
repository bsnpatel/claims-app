import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {from, Observable} from 'rxjs';
import {delay} from 'rxjs/operators';
import {ClaimLine} from '../models/ClaimLine.model';
import { environment } from 'src/environments/environment';


@Injectable()
export class ClaimLineService {
	nextId =  1;
	temp: ClaimLine = {
		isDirty: false,
		revenueCd: null,
		modifierCd1: null,
		modifierCd2: null,
		modifierCd3: null,
		modifierCd4: null,
		lineCharge: null,
		procedureCd: null,
		diagPointer: null,
		lineNo: null,
		id: null,
		units: null,
		ndcCode: null,
		ndcUnits: null,
		placeOfService: '',
		ndcUnitType: '',
		};

	constructor(private http: HttpClient) {
	}

	findClaimLineById(id: string): Observable<ClaimLine> {
		//	return from([this.temp])
		//		.pipe(delay(500));

		// return of(fakeResponse).delay(5000);
		return this.http.get<ClaimLine>(environment.apiEndpoint + `/api/claimLine/${id}`);
	}

	findAllClaimLine(): Observable<ClaimLine[]> {
		//	return from([[this.temp]]).pipe(delay(500));

		// return this.http.get('/api/claimLine')
		// .pipe(
		// map(res => res['payload'])
		// );
		return this.http.get<ClaimLine[]>(environment.apiEndpoint + `/api/claimLine`);
	}

	findAllClaimLineByParentId(parentId : string): Observable<ClaimLine[]> {
	//	return from([[this.temp]]).pipe(delay(500));

		// return this.http.get('/api/claimLine')
		// .pipe(
		// map(res => res['payload'])
		// );
		return this.http.get<ClaimLine[]>(environment.apiEndpoint + `/api/claimLines/${parentId}`);
	}				
	deleteClaimLine(id: string): Observable<ClaimLine> {
	//return of<string>(id).pipe(delay(500));
	let headers = new HttpHeaders()
	.set('Content-Type', 'application/json')
	.set('Accept', 'application/json');
	return this.http.delete<ClaimLine>(environment.apiEndpoint + `/api/claimLine/${id}`,{headers: headers});
	}				

	saveClaimLine(changes: ClaimLine): Observable<ClaimLine> {
		//	let obj: ClaimLine = {...changes};
		//	if (obj.id === '') {
		//		this.nextId = this.nextId + 1;
		//		obj.id = string(this.nextId);
		//	}
		//	return from([obj]).pipe(delay(500));
		
		let headers = new HttpHeaders()
		.set('Content-Type', 'application/json')
		.set('Accept', 'application/json');
		let body = JSON.stringify({changes});
		return this.http.put<ClaimLine>(environment.apiEndpoint + `/api/claimLine`,
		 body, {headers: headers});
	}
}
