import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {
	ClaimActionTypes,
	ClaimLoaded,
	AllClaimLoaded,
	LoadClaim,
	LoadClaims,
	LoadClaimsByParentId,
	AllClaimByParentIdLoaded,
	AllClaimByParentIdLoadFailed,
	UpdateClaim,
	UpdateClaimFail,
	UpdateClaimSuccess,
	DeleteClaim,
	DeleteClaimSuccess,
	DeleteClaimFail,
	AllClaimLoadFailed,
	NoAction
} from '../actions/Claim.actions';
import {of} from 'rxjs';
import {filter, map, mergeMap, withLatestFrom} from 'rxjs/operators';
import {select, Store} from '@ngrx/store';

import {AppState} from 'src/app/reducers/index';
import {ClaimService} from '../services/Claim.service';
			
import {loaded} from '../selectors/Claim.selector';
import {catchError, switchMap} from 'rxjs/internal/operators';

@Injectable()
export class ClaimEffects {

	@Effect()
		loadClaim$ = this.actions$
			.pipe(
				ofType<LoadClaim>(ClaimActionTypes.LoadClaim),
				mergeMap(action => this.claimService.findClaimById(action.payload.claim)),
				map(claim => new ClaimLoaded({claim}))
			);

  @Effect()
  loadAllClaim$ = this.actions$
  	.pipe(
  		ofType<LoadClaims>(ClaimActionTypes.LoadClaims),
  		withLatestFrom(this.store.pipe(select(loaded))),
  		filter(([action, indicator]) => !indicator),
  		switchMap((action) => {
  			return this.claimService.findAllClaim()
  					.pipe(
  					map(info => new AllClaimLoaded({claims: info})),
  				catchError(error => of(new AllClaimLoadFailed(error)))
  				);
  	})
  );
  
  @Effect()
  loadAllClaimByParentId$ = this.actions$
  	.pipe(
  		ofType<LoadClaimsByParentId>(ClaimActionTypes.LoadClaimsByParentId),
  		withLatestFrom(this.store.pipe(select(loaded))),
  		filter(([action, indicator]) => !indicator),
  		switchMap((action) => {
  			return this.claimService.findAllClaimByParentId(action[0].payload.parentId)
  					.pipe(
  					map(info => new AllClaimByParentIdLoaded({claims: info})),
  				catchError(error => of(new AllClaimByParentIdLoadFailed(error)))
  				);
  	})
  );
@Effect()
	updateClaim$ = this.actions$
		.pipe(
			ofType<UpdateClaim>(ClaimActionTypes.UpdateClaim),
			switchMap((action) => {
				return this.claimService
					.saveClaim(action.payload.claim)
						.pipe(
						map(info => new UpdateClaimSuccess({claim: info})),
					catchError(error => of(new UpdateClaimFail(error)))
					);
		})
	);

	@Effect()
	deleteClaim$ = this.actions$
		.pipe(
			ofType<DeleteClaim>(ClaimActionTypes.DeleteClaim),
			switchMap((action) => {
				return this.claimService
					.deleteClaim(action.payload.id)
					.pipe(
						map(info => new DeleteClaimSuccess({ id: info.id })),
						catchError(error => of(new DeleteClaimFail(error)))
					);
			})
		);

	constructor(private actions$: Actions, private claimService: ClaimService,private store: Store<AppState>) {
	}
}
