import {Component} from '@angular/core';
import {Store} from '@ngrx/store';
import {Router} from '@angular/router';
import {AppState} from 'src/app/reducers';

@Component({
	selector: 'claims-app',
	templateUrl: './ClaimsApp.component.html',
	styleUrls: ['./ClaimsApp.component.scss']
})
export class ClaimsApp {
	title = '';
		
	constructor(private store: Store<AppState>, private router: Router) {
	}

	onActivate($event: any) {
	}

	onDeactivate($event: any) {
	}
}
