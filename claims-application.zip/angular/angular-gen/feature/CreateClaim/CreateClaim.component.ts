import {AfterViewInit, ChangeDetectionStrategy, Component, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {Observable, Subscription} from 'rxjs/index';
import {select, Store} from '@ngrx/store';
import {FlowComponent} from 'src/app/shared/ng-flow/flow-component';
import {AppState} from 'src/app/reducers/index';
import {FormField} from 'src/app/shared/fwk/form-field';
import {selectClaim,
selectAllClaim, 
 uiState, error} from 'angular-gen/core/selectors/Claim.selector';
import {
	LoadClaims, 
	ResetClaim, 
	SelectClaim,
	UpdateClaim,
	DeleteClaim,
	UpdateClaimUiState,
	ResetClaimErrorState
} from 'angular-gen/core/actions/Claim.actions';
import {Claim} from 'angular-gen/core/models/Claim.model';

@Component({
	selector: 'create-claim',
	template: `
	<create-claim-detail
	[model]="model$ | async"
	[uiState]="uiState$ | async"
	[error]="error$ | async"
	(next)="onNext($event)"
	(previous)="onPrevious($event)"
	
	[claimTypeOptions]="claimTypeOptions"
	>
	</create-claim-detail>
	 `,
	 encapsulation: ViewEncapsulation.None,
	 changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateClaim extends FlowComponent implements OnInit, AfterViewInit {
	model$: Observable<Claim>;
	uiState$: Observable<string>;
	error$: Observable<any>;
	claimTypeOptions: FormField[] = [
	{name:'Professional', value:'P'},
	{name:'Inpatient', value:'I'},
	{name:'Outpatient', value:'O'},
	];
	constructor(private store: Store<AppState>) {
		super();
		this.stateId = 'feature.CreateClaim';
	}

	onNext(arg : any) {
		var model=arg.model;
		if (model.isDirty) {
			this.store.dispatch(new UpdateClaim({claim: model}));			
		} else {
			this.store.dispatch(new UpdateClaimUiState({uiState: 'updated'}));
		}	

	}
	
	

	onPrevious($event: any) {
		this.store.dispatch(new ResetClaimErrorState());
		this.triggerFlowEvent('previous');
		
	}
	
	

	uiStateChange(state: string) {
		console.log(state);
		switch (state) {
			case '': {	
			this.store.dispatch(new LoadClaims());
			break;
			}
			case 'loaded': {
				this.store.dispatch(new UpdateClaimUiState({uiState: 'ready'}));
				break;
			}
			case 'updated': {
				this.store.dispatch(new UpdateClaimUiState({uiState: 'ready'}));
					this.triggerFlowEvent('next');
				break;
			}
			default: {
				break;
			}
		}
	}

	ngOnInit(): void {
		this.model$ = this.store.pipe(select(selectClaim()));
		this.uiState$ = this.store.pipe(select(uiState));
		this.error$ = this.store.pipe(select(error));
					
		this.subscription.add(this.uiState$.subscribe(state => {
			this.uiStateChange(state);
		}));					
		
	}
	ngAfterViewInit(): void {
	}
}
