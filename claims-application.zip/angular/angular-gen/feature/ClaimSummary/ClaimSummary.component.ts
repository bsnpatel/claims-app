import {ChangeDetectionStrategy, Component, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {select, Store} from '@ngrx/store';
import {Observable, Subscription} from 'rxjs';
import {FlowComponent} from 'src/app/shared/ng-flow/flow-component';
import {AppState} from 'src/app/reducers/index';
import {ActivatedRoute, Router} from "@angular/router";
import {selectClaim,
selectAllClaim, 
 uiState, error} from 'angular-gen/core/selectors/Claim.selector';
import {
	LoadClaims, 
	ResetClaim, 
	SelectClaim,
	UpdateClaim,
	DeleteClaim,
	UpdateClaimUiState,
	ResetClaimErrorState
} from 'angular-gen/core/actions/Claim.actions';
import {Claim} from 'angular-gen/core/models/Claim.model';
@Component({
	selector: 'claim-summary',
	template: `
	<claim-summary-list
		[model]="model$ | async"
		[displayedColumns]="columns"
		[uiState]="uiState$ | async"
		[error]="error$ | async"
		(selectAction)="onSelectAction($event)"
		(deleteAction)="onDeleteAction($event)"
		(addAction)="onAddAction($event)"
		(editAction)="onEditAction($event)"
		(next)="onNext($event)"
		(previous)="onPrevious($event)"
	>
	</claim-summary-list>
	 `,
	 encapsulation: ViewEncapsulation.None,
	 changeDetection: ChangeDetectionStrategy.OnPush
})
export class ClaimSummary extends FlowComponent implements OnInit, OnDestroy {
	model$: Observable<Claim[]>;
	
		parentModel$: Observable<any>;
	
	columns: string[] = [
		'',
		'',
		'',
		'',
		'',
		'ACTIONS'
	];
	uiState$: Observable<string>;
	error$: Observable<any>;
	
	constructor(private store: Store<AppState>, private router: Router, private route: ActivatedRoute) {
		super();
		this.stateId = 'feature.ClaimSummary';
	}
	ngOnInit(): void {
		this.uiState$ = this.store.pipe(select(uiState));
		this.error$ = this.store.pipe(select(error));
		this.model$ = this.store.pipe(select(selectAllClaim));
		this.subscription.add(this.uiState$.subscribe(state => {
				this.uiStateChange(state);
		}));


	}
	
	onNext(obj) {
		this.triggerFlowEvent('next');
	}

	onPrevious(obj) {
		this.store.dispatch(new ResetClaimErrorState());
		this.triggerFlowEvent('previous');
	}

	onDeleteAction(obj) {
		this.store.dispatch(new DeleteClaim({id:obj.id}));
	}

	onEditAction(obj) {
	console.log('onEditAction:'+ obj);
	this.store.dispatch(new SelectClaim({claim: obj }));
	this.triggerFlowEvent('edit');
	}

	onAddAction(obj) {
	console.log('onAddAction:'+ obj);
	this.store.dispatch(new ResetClaim());
	this.triggerFlowEvent('add');
	}

	onSelectAction(obj) {
	console.log('onSelectAction:'+ obj);
	this.store.dispatch(new SelectClaim({claim: obj }));
	this.triggerFlowEvent('select');
	}
	

	uiStateChange(state: string) {
		console.log(state);
		switch (state) {
			case '': {	
				this.store.dispatch(new LoadClaims());
				break;
			}
			case 'loaded': {
				this.store.dispatch(new UpdateClaimUiState({uiState: 'ready'}));
				break;
			}
			case 'deleted': {
				this.store.dispatch(new UpdateClaimUiState({uiState: 'ready'}));
				break;
			}
			default: {
				break;
			}
		}
	}

}
