import {ChangeDetectionStrategy, Component, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {select, Store} from '@ngrx/store';
import {Observable, Subscription} from 'rxjs';
import {FlowComponent} from 'src/app/shared/ng-flow/flow-component';
import {AppState} from 'src/app/reducers/index';
import {ActivatedRoute, Router} from "@angular/router";
import {selectClaimLine,
selectAllClaimLine, 
 uiState, error} from 'angular-gen/core/selectors/ClaimLine.selector';
import {
	LoadClaimLines, 
	ResetClaimLine, 
	SelectClaimLine,
	UpdateClaimLine,
	DeleteClaimLine,
	UpdateClaimLineUiState,
	ResetClaimLineErrorState
} from 'angular-gen/core/actions/ClaimLine.actions';
import {ClaimLine} from 'angular-gen/core/models/ClaimLine.model';
@Component({
	selector: 'claim-line-summary',
	template: `
	<claim-line-summary-list
		[model]="model$ | async"
		[displayedColumns]="columns"
		[uiState]="uiState$ | async"
		[error]="error$ | async"
		(selectAction)="onSelectAction($event)"
		(deleteAction)="onDeleteAction($event)"
		(addAction)="onAddAction($event)"
		(editAction)="onEditAction($event)"
		(next)="onNext($event)"
		(previous)="onPrevious($event)"
	>
	</claim-line-summary-list>
	 `,
	 encapsulation: ViewEncapsulation.None,
	 changeDetection: ChangeDetectionStrategy.OnPush
})
export class ClaimLineSummary extends FlowComponent implements OnInit, OnDestroy {
	model$: Observable<ClaimLine[]>;
	
		parentModel$: Observable<any>;
	
	columns: string[] = [
		'',
		'',
		'',
		'',
		'',
		'',
		'ACTIONS'
	];
	uiState$: Observable<string>;
	error$: Observable<any>;
	
	constructor(private store: Store<AppState>, private router: Router, private route: ActivatedRoute) {
		super();
		this.stateId = 'feature.ClaimLineSummary';
	}
	ngOnInit(): void {
		this.uiState$ = this.store.pipe(select(uiState));
		this.error$ = this.store.pipe(select(error));
		this.model$ = this.store.pipe(select(selectAllClaimLine));
		this.subscription.add(this.uiState$.subscribe(state => {
				this.uiStateChange(state);
		}));


	}
	
	onNext(obj) {
		this.triggerFlowEvent('next');
	}

	onPrevious(obj) {
		this.store.dispatch(new ResetClaimLineErrorState());
		this.triggerFlowEvent('previous');
	}

	onDeleteAction(obj) {
		this.store.dispatch(new DeleteClaimLine({id:obj.id}));
	}

	onEditAction(obj) {
	console.log('onEditAction:'+ obj);
	this.store.dispatch(new SelectClaimLine({claimLine: obj }));
	this.triggerFlowEvent('edit');
	}

	onAddAction(obj) {
	console.log('onAddAction:'+ obj);
	this.store.dispatch(new ResetClaimLine());
	this.triggerFlowEvent('add');
	}

	onSelectAction(obj) {
	console.log('onSelectAction:'+ obj);
	this.store.dispatch(new SelectClaimLine({claimLine: obj }));
	this.triggerFlowEvent('select');
	}
	

	uiStateChange(state: string) {
		console.log(state);
		switch (state) {
			case '': {	
				this.store.dispatch(new LoadClaimLines());
				break;
			}
			case 'loaded': {
				this.store.dispatch(new UpdateClaimLineUiState({uiState: 'ready'}));
				break;
			}
			case 'deleted': {
				this.store.dispatch(new UpdateClaimLineUiState({uiState: 'ready'}));
				break;
			}
			default: {
				break;
			}
		}
	}

}
