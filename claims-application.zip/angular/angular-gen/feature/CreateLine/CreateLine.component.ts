import {AfterViewInit, ChangeDetectionStrategy, Component, OnDestroy, OnInit, ViewEncapsulation} from '@angular/core';
import {Observable, Subscription} from 'rxjs/index';
import {select, Store} from '@ngrx/store';
import {FlowComponent} from 'src/app/shared/ng-flow/flow-component';
import {AppState} from 'src/app/reducers/index';
import {FormField} from 'src/app/shared/fwk/form-field';
import {selectClaimLine,
selectAllClaimLine, 
 uiState, error} from 'angular-gen/core/selectors/ClaimLine.selector';
import {
	LoadClaimLines, 
	ResetClaimLine, 
	SelectClaimLine,
	UpdateClaimLine,
	DeleteClaimLine,
	UpdateClaimLineUiState,
	ResetClaimLineErrorState
} from 'angular-gen/core/actions/ClaimLine.actions';
import {ClaimLine} from 'angular-gen/core/models/ClaimLine.model';

@Component({
	selector: 'create-line',
	template: `
	<create-line-detail
	[model]="model$ | async"
	[uiState]="uiState$ | async"
	[error]="error$ | async"
	(next)="onNext($event)"
	(previous)="onPrevious($event)"
	
	[placeOfServiceOptions]="placeOfServiceOptions"
	>
	</create-line-detail>
	 `,
	 encapsulation: ViewEncapsulation.None,
	 changeDetection: ChangeDetectionStrategy.OnPush
})
export class CreateLine extends FlowComponent implements OnInit, AfterViewInit {
	model$: Observable<ClaimLine>;
	uiState$: Observable<string>;
	error$: Observable<any>;
	placeOfServiceOptions: FormField[] = [
	{name:'Office', value:'11'},
	{name:'Inpatient Hospital', value:'21'},
	{name:'On Campus-Outpatient Hospital', value:'22'},
	{name:'Pharmacy', value:'01'},
	{name:'Telehealth', value:'02'},
	{name:'School', value:'03'},
	{name:'Home', value:'12'},
	{name:'Assisted Living Facility', value:'13'},
	{name:'Group Home', value:'14'},
	{name:'Mobile Unit', value:'15'},
	{name:'Temporary Lodging', value:'16'},
	{name:'Walk-in Retail Health Clinic', value:'17'},
	{name:'Off Campus-Outpatient Hospital', value:'19'},
	{name:'Urgent Care Facility', value:'20'},
	{name:'Emergency Room – Hospital', value:'23'},
	{name:'Ambulatory Surgical Center', value:'24'},
	{name:'Birthing Center', value:'25'},
	{name:'Skilled Nursing Facility', value:'31'},
	{name:'Public Health Clinic', value:'71'},
	{name:'Independent Laboratory', value:'81'},
	];
	constructor(private store: Store<AppState>) {
		super();
		this.stateId = 'feature.CreateLine';
	}

	onNext(arg : any) {
		var model=arg.model;
		if (model.isDirty) {
			this.store.dispatch(new UpdateClaimLine({claimLine: model}));			
		} else {
			this.store.dispatch(new UpdateClaimLineUiState({uiState: 'updated'}));
		}	

	}
	
	

	onPrevious($event: any) {
		this.store.dispatch(new ResetClaimLineErrorState());
		this.triggerFlowEvent('previous');
		
	}
	
	

	uiStateChange(state: string) {
		console.log(state);
		switch (state) {
			case '': {	
			this.store.dispatch(new LoadClaimLines());
			break;
			}
			case 'loaded': {
				this.store.dispatch(new UpdateClaimLineUiState({uiState: 'ready'}));
				break;
			}
			case 'updated': {
				this.store.dispatch(new UpdateClaimLineUiState({uiState: 'ready'}));
					this.triggerFlowEvent('next');
				break;
			}
			default: {
				break;
			}
		}
	}

	ngOnInit(): void {
		this.model$ = this.store.pipe(select(selectClaimLine()));
		this.uiState$ = this.store.pipe(select(uiState));
		this.error$ = this.store.pipe(select(error));
					
		this.subscription.add(this.uiState$.subscribe(state => {
			this.uiStateChange(state);
		}));					
		
	}
	ngAfterViewInit(): void {
	}
}
