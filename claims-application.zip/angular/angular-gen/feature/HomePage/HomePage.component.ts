import {
  AfterViewInit,
  ChangeDetectionStrategy,
  Component,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChange,
  SimpleChanges,
  ViewEncapsulation
} from '@angular/core';
import {FlowComponent} from 'src/app/shared/ng-flow/flow-component';
import { FormBuilder, FormGroup,Validators,FormControl } from '@angular/forms';

import {FormField} from 'src/app/shared/fwk/form-field';
import {Subscription} from "rxjs/index";

@Component({
	selector: 'home-page',
	templateUrl: './HomePage.component.html',
	styleUrls: ['./HomePage.component.scss'],
	encapsulation: ViewEncapsulation.None,
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class HomePage  {

}

