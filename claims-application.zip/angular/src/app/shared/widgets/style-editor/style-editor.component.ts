import { Component, EventEmitter, Input, OnChanges, Output, SimpleChange, SimpleChanges } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { Store } from "@ngrx/store";
import { AppState } from "src/app/reducers";
import { View } from "../../fwk/view";
import { DndItem } from "../../model/dnditem";
import { deepCopy, extend } from "../../utils";

@Component({
  selector: 'bolt-style-editor',
  templateUrl: './style-editor.component.html',
  styleUrls: ['./style-editor.component.scss']
})
export class StyleEditorComponent extends View<DndItem>  {
  @Output()
  save = new EventEmitter();
  
  @Output()
  delete = new EventEmitter();
  
  constructor(protected _formBuilder: FormBuilder, private store: Store<AppState>) {
    super(_formBuilder);
    this.buildForm();
  }
  ngOnInit() {
    this.formErrors = {
          backgroundColor: '',
          margin:'',
          textAlign:'',
          color: '',
          fontSize: '',
          clazz:'',
          fxLayout:'',
          fxFlex:'',
          fxLayoutAlign:''
    };

    this.validationMessages = {


    }
    this.checkFormStatus();
  }

  getModel(): DndItem {
    var modified = deepCopy(this.model);
    extend(modified, this.form.value);
    modified.isDirty = true;
    return modified
  }


  onSave() {
    this.save.next( this.getModel() );
    this.form.reset(this.form.value);
  }

  onDelete() {
    this.delete.next(this.getModel());
  }


  patchForm(change: SimpleChange) {
    const form = this.getForm();
    if (form && !form.dirty) {
      if (change.currentValue !== null && change.currentValue !== undefined) {
        form.patchValue({
          backgroundColor: change.currentValue.backgroundColor,
          margin:change.currentValue.margin,
          textAlign:change.currentValue.textAlign,
          color: change.currentValue.color,
          fontSize: change.currentValue.fontSize,
          clazz:change.currentValue.clazz,
          fxLayout:change.currentValue.fxLayout,
          fxFlex:change.currentValue.fxFlex,
          fxLayoutAlign:change.currentValue.fxLayoutAlign
         

        });
      }
    }
  }

  buildForm() {
    if (!this.form) {
      this.form = this._formBuilder.group({
        backgroundColor: [''],
        margin: [''],
        textAlign: [''],
        color: [''],
        fontSize: [''],
        clazz:[''],
        fxLayout:[''],
        fxFlex:[''],
        fxLayoutAlign:['']
      });
    }
  }

}