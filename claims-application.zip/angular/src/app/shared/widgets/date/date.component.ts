import { Component, Input, OnInit, AfterViewInit, ViewChild, SimpleChanges, SimpleChange, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup,Validators,FormControl } from '@angular/forms';
import {Subscription, Observable} from "rxjs/index";
import { FieldComponent } from '../field/field';

@Component({
  selector: 'bolt-date',
  templateUrl: './date.component.html',
  styleUrls: ['./date.component.scss']
})
export class DateComponent extends FieldComponent {

    constructor(protected _formBuilder: FormBuilder) {
      super(_formBuilder);
    }
}