import { Component, Input, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { SwiperComponent, SwiperDirective } from 'ngx-swiper-wrapper';

@Component({
  selector: 'bolt-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss']
})
export class CarouselComponent implements OnInit, AfterViewInit {

  @Input() slidesPerView = 3;
  @Input() centeredSlides = false;
  @Input() index = 1;
  @Input() showButtons = true;
  @Input() spaceBetween = 10;
  @Input() totalSlides;
  /*
   This can be called from any other HTML pages
   Syntax : <app-carousel [slides]="images"></app-carousel>
   */

  config: any;
  @ViewChild(SwiperComponent,{static:false}) componentRef?: SwiperComponent;
  @ViewChild(SwiperDirective,{static:false}) directiveRef?: SwiperDirective;

  constructor() {
  }

  ngOnInit() {
    this.config = {
      pagination: {
        el: '.swiper-pagination',
        type: 'bullets'
      },
      // pagination: '.swiper-pagination',
      paginationClickable: true,
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      spaceBetween: this.spaceBetween,
      slidesPerView: this.slidesPerView,
      centeredSlides: this.centeredSlides,
      keyboardControl: true,
      setIndex: this.index
    };
  }

  next() {
    if (this.componentRef.isAtLast) {
      this.componentRef.directiveRef.setIndex(0);
    } else {
    let elem = <HTMLElement>document.getElementsByClassName('swiper-button-next')[0] as HTMLElement;
    elem.removeAttribute('disabled');
    elem.click();
    }
  }

  previous() {
    if (this.componentRef.isAtFirst) {
      this.componentRef.directiveRef.setIndex(this.totalSlides - 1);
    } else {
      let elem = <HTMLElement>document.getElementsByClassName('swiper-button-prev')[0] as HTMLElement;
      elem.removeAttribute('disabled');
      elem.click();
    }
  }
  ngAfterViewInit(): void {
    // this.config.loop = true;
  }
}
