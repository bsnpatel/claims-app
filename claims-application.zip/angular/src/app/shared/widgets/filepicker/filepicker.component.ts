import { Component, Input, OnInit, AfterViewInit, ViewChild, SimpleChanges, SimpleChange, OnChanges, Output, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { Subscription, Observable } from "rxjs/index";
import { FieldComponent } from '../field/field';

@Component({
  selector: 'bolt-filepicker',
  templateUrl: './filepicker.component.html',
  styleUrls: ['./filepicker.component.scss']
})
export class FilepickerComponent extends FieldComponent {

  constructor(protected _formBuilder: FormBuilder) {
    super(_formBuilder);
  }

  @Output()
  fileToUpload = new EventEmitter<string>();

  handleFileInput(files: FileList) {
    let reader = new FileReader();
    reader.readAsDataURL(files.item(0));
    reader.onload = () => {
      this.fileToUpload.emit(reader.result.toString().split(',')[1])
    }
  }
}