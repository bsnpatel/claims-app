import { AfterContentInit, ContentChildren, QueryList, ViewChildren } from "@angular/core";
import { AfterViewInit } from "@angular/core";
import { Component, Input } from "@angular/core";
import { NavigationStart, Router, RouterEvent } from "@angular/router";
import { Subject } from "rxjs";
import { filter, takeUntil } from "rxjs/operators";
import { TabComponent } from "../tab/tab.component";

@Component({
    selector: 'bolt-nav',
    templateUrl: './nav.component.html',
    styleUrls: ['./nav.component.scss']
})
export class TopNavComponent implements AfterContentInit {
    @ContentChildren(TabComponent) contentChildren!: QueryList<TabComponent>;

    constructor(private router: Router) {
    }
    ngAfterContentInit(): void {
        this.contentChildren.forEach(child => child.topNav = this)
    }
    clearAll() {
        this.contentChildren.forEach(child => child.active = "false")
    }

    private destroyed$ = new Subject();

    ngOnInit() {
        this.router.events
            .pipe(
                filter((event: RouterEvent) => event instanceof NavigationStart),
                takeUntil(this.destroyed$),
            )
            .subscribe((event: NavigationStart) => {
                let path = event.url.split('/')[1]
                let child = this.contentChildren.find(child => child.path === path)
                if (child) {
                    this.clearAll()
                    child.active = "true"
                }
            });
    }
}