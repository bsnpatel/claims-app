import { CdkDragDrop, CdkDragEnter, CdkDragExit, moveItemInArray } from '@angular/cdk/drag-drop';
import { Component, Input, OnInit, AfterViewInit, ViewChild, Output,EventEmitter } from '@angular/core';


import { SwiperComponent, SwiperDirective } from 'ngx-swiper-wrapper';
import { DndItem } from '../../model/dnditem';
import { BoltDnDWidgetService } from './dnd-widget-service';

@Component({
  selector: 'dndwidget',
  templateUrl: './dnd-widget-component.html',
  styleUrls: ['./dnd-widget-component.scss']
})
export class DnDWidgetComponent implements OnInit, AfterViewInit {


@Input() id: string;

showControls:false
  constructor(private boltDnDWidgetService: BoltDnDWidgetService) {
  }

  ngOnInit() {

  }


  ngAfterViewInit(): void {
    // this.config.loop = true;
  }

  
	onDragStart(event: DragEvent) {
		console.log("drag started", JSON.stringify(event, null, 2));
	}

	onDragEnd(event: DragEvent) {
		console.log("drag ended", JSON.stringify(event, null, 2));
	}

	onDraggableCopied(event: DragEvent) {
		console.log("draggable copied", JSON.stringify(event, null, 2));
	}

	onDraggableLinked(event: DragEvent) {
		console.log("draggable linked", JSON.stringify(event, null, 2));
	}



	onDragCanceled(event: DragEvent) {
		console.log("drag cancelled", JSON.stringify(event, null, 2));
	}

	onDragover(event: DragEvent) {
		console.log("dragover", JSON.stringify(event, null, 2));
	}

	private canBeDropped(event: CdkDragDrop<DndItem, DndItem>): boolean {
		const movingItem: DndItem = event.item.data;
		return event.previousContainer.id !== event.container.id
			&& this.isNotSelfDrop(event)
			&& !this.hasChild(movingItem, event.container.data);
	}


	public onDragDrop(event: CdkDragDrop<DndItem>) {
		console.log("dndwidget method Called")
		if (event.container.id == "palette") {
			return
		}
		event.container.element.nativeElement.classList.remove('active');
		if (this.canBeDropped(event)) {
			const movingItem: DndItem = event.item.data;
			if (!event.container.data.children) {
				event.container.data.children = []
			}
			event.container.data.children.push(movingItem);
			if (event.previousContainer.id !== "palette" && event.previousContainer.data.children) {
				event.previousContainer.data.children = event.previousContainer.data.children.filter((child) => child.id !== movingItem.id);
			}
		} else {
			moveItemInArray(
				event.container.data.children,
				event.previousIndex,
				event.currentIndex
			);
		}
	}
	private isNotSelfDrop(event: CdkDragDrop<DndItem> | CdkDragEnter<DndItem> | CdkDragExit<DndItem>): boolean {
		return event.container.data.id !== event.item.data.id;
	}

	private hasChild(parentItem: DndItem, childItem: DndItem): boolean {
		if (parentItem.children) {
			const hasChild = parentItem.children.some((item) => item.id === childItem.id);
			return hasChild ? true : parentItem.children.some((item) => this.hasChild(item, childItem));
		} else {
			return false;
		}
	}

	
}
