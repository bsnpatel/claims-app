import { Component, EventEmitter, Input, OnInit, Output } from "@angular/core";
import { BoltResourceService } from "../services/backend.service";

@Component({
  selector: 'bolt-explorer',
  templateUrl: './explorer.component.html',
  styleUrls: ['./explorer.component.scss']
})
export class ExplorerComponent implements OnInit {
  @Input()
  resourceList: string[]

  selected: string;

  @Output()
  select = new EventEmitter<string>();

  constructor(private resourceService: BoltResourceService) {

  }
  ngOnInit(): void {
    this.selected = this.resourceService.getSelection()
  }
  onClick(resource: string) {
    this.selected = resource
    this.select.next(resource)
  }
  isSelected(resource: string) {
    var flag = this.selected === resource;
    return flag ? 'selected' : '';
  }
}