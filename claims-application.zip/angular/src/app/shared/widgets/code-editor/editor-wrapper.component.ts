
import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import { Observable } from 'rxjs';
import { EditorResource } from '../models/resource.model';
import { BoltResourceService } from '../services/backend.service';
;

@Component({
  selector: 'bolt-editor-wrapper',
  templateUrl: './editor-wrapper.component.html',
  styleUrls: ['./editor-wrapper.component.scss']
})
export class CodeEditorWrapperComponent implements OnInit{

  resource$: Observable<EditorResource>
  resourceList$: Observable<string[]>

  @Output()
  resourceChange= new EventEmitter<EditorResource>();
  
  constructor( private resourceService: BoltResourceService) { 
 
  }
  ngOnInit(): void {
    this.resourceService.setSelection("/app/BoltApplication.sml");
    this.resource$= this.resourceService.getSelectedResource();
    this.resourceList$= this.resourceService.getResourceList();
  }
  onSelect($event:any){
    this.resourceService.setSelection($event);
  }
}

