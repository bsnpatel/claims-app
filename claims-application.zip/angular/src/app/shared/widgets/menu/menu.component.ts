import { Component, Input } from "@angular/core";

@Component({
    selector: 'bolt-menu',
    templateUrl: './menu.component.html',
    styleUrls: ['./menu.component.scss']
  })
  export class MenuComponent  {
    @Input()
    model: any;

    @Input()
    label: string;


  }