import { Component, Input, OnInit, AfterViewInit, ViewChild, SimpleChanges, SimpleChange, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup,Validators,FormControl } from '@angular/forms';
import {Subscription, Observable} from "rxjs";
import { FieldComponent } from '../field/field';

@Component({
  selector: 'bolt-dropdown',
  templateUrl: './drop-down.component.html',
  styleUrls: ['./drop-down.component.scss']
})
export class DropdownComponent extends FieldComponent {
 
    @Input()
    elements: any;

    @Input()
    valuefield: string;

    @Input()
    namefield: string;

    constructor(protected _formBuilder: FormBuilder) {
      super(_formBuilder);
    }
    
    getName(element){
    	return element[this.namefield]
    }
    
    getValue(element){
    	return element[this.valuefield]
    }
}