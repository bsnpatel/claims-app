import { Component, Input, OnInit, AfterViewInit, ViewChild, SimpleChanges, SimpleChange, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup,Validators,FormControl } from '@angular/forms';
import {Subscription, Observable} from "rxjs/index";
import { FieldComponent } from '../field/field';

@Component({
  selector: 'bolt-text',
  templateUrl: './text.component.html',
  styleUrls: ['./text.component.scss']
})
export class TextComponent extends FieldComponent {

    constructor(protected _formBuilder: FormBuilder) {
      super(_formBuilder);
    }
}