import { Component, Input} from '@angular/core';


@Component({
  selector: 'bolt-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent  {
 
    @Input()
    label: string;

    @Input()
    id: string;

    @Input()
    formGroup: any;


}