
import { Component, Input } from '@angular/core';

@Component({
    selector: 'bolt-label',
    template: `
    <div class="top-input-field top-label">
        <h3>{{label}}</h3>        
    </div>
    `
  })
  export class LabelComponent   {

  
      @Input()
      label: string;
  }