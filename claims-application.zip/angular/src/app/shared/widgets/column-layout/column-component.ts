import { Component, Input, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { SwiperComponent, SwiperDirective } from 'ngx-swiper-wrapper';

@Component({
  selector: 'bolt-layout-item',
  templateUrl: './column-component.html',
  styleUrls: ['./column-component.scss']
})
export class ColumnComponent implements OnInit, AfterViewInit {


  @Input() size;


  constructor() {
  }

  ngOnInit() {

  }


  ngAfterViewInit(): void {
    // this.config.loop = true;
  }
}
