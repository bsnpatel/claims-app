import { Component } from "@angular/core";
import { RxStompService,  } from "@stomp/ng2-stompjs";
import { RxStompState,  } from "@stomp/rx-stomp";
import { Message } from '@stomp/stompjs';
import { Subscription } from "rxjs";

@Component({
  selector: 'bolt-messages',
  templateUrl: './messages.component.html',
  styleUrls: ['./messages.component.scss']
})
export class StompMessagesComponent {
  receivedMessages: any[] = [];
  topicSubscription: Subscription;
  connectionSubscription: Subscription;
  state: string;
  show:boolean=false;

  constructor(private rxStompService: RxStompService) {

  }
  ngOnInit() {
    this.topicSubscription = this.rxStompService.watch('/topic/workspace').subscribe((message: Message) => {
      var msg: string;
      if (message.isBinaryBody) {
        msg = new TextDecoder().decode(message.binaryBody)
      } else {
        msg = message.body
      }
      this.receivedMessages.push(JSON.parse(msg).content);
    });
    this.connectionSubscription = this.rxStompService.connectionState$.subscribe(state => {
      this.state = RxStompState[state]
    });
  }

  ngOnDestroy() {
    this.topicSubscription.unsubscribe();
  }
  onClick() {
    this.receivedMessages = []
  }
  onSendMessage() {
    const message = `Message generated at ${new Date}`;
    this.rxStompService.publish({ destination: '/topic/workspace', body: message });
  }
}