import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
    selector: 'bolt-menuitem',
    templateUrl: './menuitem.component.html',
    styleUrls: ['./menuitem.component.scss']
  })
  export class MenuItemComponent  {
    @Input()
    model: any;

    @Input()
    label: string;

    @Input()
    id: string;

    @Input()
    menuIcon: string;
    
    @Output()
    action = new EventEmitter();

    onClick() {
        this.action.next();
    }

  }