import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject, } from 'rxjs';

import { DndItem } from '../../model/dnditem';
import { deepCopy } from '../../utils';
import { StyleService } from '../services/style.service';
@Injectable()
export class DndItemService {

    private EDITABLE_PLACEHOLDER: DndItem = { id: 'not-editable', name: 'editable', fieldType: 'editable-placeholder', orientation: 'column', children: [] } as DndItem;
    private ROOT_PLACEHOLDER: DndItem = { id: 'root-placeholder', name: 'root-placeholder', orientation: 'column', children: [] } as DndItem;
    parentItem$: BehaviorSubject<DndItem> = new BehaviorSubject<DndItem>(this.ROOT_PLACEHOLDER);

    selectedItem$: BehaviorSubject<DndItem> = new BehaviorSubject<DndItem>({ id: '', name: '', children: [] } as DndItem);

    private parentItem: DndItem;


    constructor(private styleService: StyleService) { }


    init(model: any) {
        if (model.layout) {
            this.parentItem = JSON.parse(model.layout);
        } else {
            this.parentItem = deepCopy(this.ROOT_PLACEHOLDER)
            let editable = { ...this.EDITABLE_PLACEHOLDER }

            if (model.type ==="Page"){
                editable.fieldType="bolt-page";
            }else if(model.type ==="Form"){
                editable.fieldType="bolt-form";
            }else if(model.type ==="Summary"){
                editable.fieldType="bolt-summary";
                editable.orientation="row";
            }
            
            editable.id = model.id
            editable.name = model.name
            this.parentItem.children.push(editable)
        }
        this.setParentItem(this.parentItem);
        this.setSelectedItem({ name: '', id: '' } as DndItem);
    }

    style(item: DndItem) {
        return {
            backgroundColor: item.backgroundColor,
            margin: item.margin,
            textAlign: item.textAlign,
            color: item.color,
            fontSize: item.fontSize
        }
    }

    clazz(item: DndItem) {
        this.styleService.setStyles("." + item.clazz, this.style(item));
        return item.clazz
    }

    save(item: DndItem) {
        if (item.id === this.parentItem.id) {
            this.parentItem.name = item.name,
                this.parentItem.id = item.id,
                this.parentItem.icon = item.icon,
                this.parentItem.viewElement = item.viewElement,
                this.parentItem.orientation = item.orientation,
                this.parentItem.fieldType = item.fieldType,
                this.parentItem.fieldLabel = item.fieldLabel

            this.parentItem.text = item.text
            this.parentItem.imageSource = item.imageSource


            this.parentItem.backgroundColor = item.backgroundColor
            this.parentItem.margin = item.margin
            this.parentItem.textAlign = item.textAlign
            this.parentItem.color = item.color
            this.parentItem.fontSize = item.fontSize
            this.parentItem.clazz = item.clazz


            this.parentItem.style = item.style

            this.parentItem.fxLayout = item.fxLayout
            this.parentItem.fxFlex = item.fxFlex
            this.parentItem.fxLayoutAlign = item.fxLayoutAlign


        } else {
            this.saveItem(this.parentItem.children, item)
        }
        this.setParentItem(this.parentItem);
        this.setSelectedItem(item);

    }

    private countAll(total, item: DndItem) {
        let subtotal=0;
        if (item.children) {
            subtotal = item.children.length
            item.children.forEach(child=> subtotal = subtotal + (this.countAll(subtotal,child)) )
            return subtotal;
        } else {
            return 0
        }
    }
    nextId() {

        return this.countAll(0, this.parentItem)

    }

    remove(item: DndItem) {
        this.removeItem(this.parentItem.children, i => i.id === item.id)
        this.setParentItem(this.parentItem);
        this.setSelectedItem({ name: '', id: '' } as DndItem);

    }
    private saveItem(items: DndItem[], item: DndItem): boolean {
        var predicate = i => i.id === item.id

        if (items) {
            var index = items.length - 1;
            while (index >= 0) {
                if (predicate(items[index])) {
                    items.splice(index, 1, item)
                    return true
                }
                this.saveItem(items[index].children, item)
                index--;
            }
        }
        return false;
    }

    private removeItem(items: DndItem[], predicate: Function): boolean {
        if (items) {
            var index = items.length - 1;
            while (index >= 0) {
                if (predicate(items[index])) {
                    items.splice(index, 1)
                    return true
                }
                this.removeItem(items[index].children, predicate)
                index--;
            }
        }
        return false;
    }
    getParentItem(): Observable<DndItem> {
        return this.parentItem$
    }
    allItems(items: DndItem[], fun: Function) {
        if (items) {
            var index = items.length - 1;
            while (index >= 0) {
                fun(items[index])
                this.allItems(items[index].children, fun)
                index--;
            }
        }
    }

    all(fun: Function) {
        fun(this.parentItem)
        this.allItems(this.parentItem.children, fun)
    }
    setParentItem(item: DndItem) {
        this.parentItem = JSON.parse(JSON.stringify(item))
        this.parentItem$.next(this.parentItem)
    }

    getSelectedItem(): Observable<DndItem> {
        return this.selectedItem$.asObservable()
    }

    setSelectedItem(item: DndItem) {

        this.selectedItem$.next(item)
    }
}