import { Component, EventEmitter, Input, OnChanges, Output, SimpleChange, SimpleChanges } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { Store } from "@ngrx/store";
import { AppState } from "src/app/reducers";
import { View } from "../../fwk/view";
import { DndItem } from "../../model/dnditem";
import { deepCopy, extend } from "../../utils";

@Component({
  selector: 'bolt-item-editor',
  templateUrl: './item-editor.component.html',
  styleUrls: ['./item-editor.component.scss']
})
export class ItemEditorComponent extends View<DndItem>  {
  @Output()
  save = new EventEmitter();

  @Output()
  delete = new EventEmitter();

  constructor(protected _formBuilder: FormBuilder, private store: Store<AppState>) {
    super(_formBuilder);
    this.buildForm();
  }
  ngOnInit() {
    this.formErrors = {
      name: '',
      id: '',
      icon: '',
      viewElement: '',
      orientation: '',
      fieldType: '',
      fieldLabel: '',
      fieldFormat: '',
      text: '',
      imageSource: '',
      slidesPerView: '',
      header: '',
      imageLink: '',
      path: '',

      required: '',
      validationmessage: '',
      model: ''
    };

    this.validationMessages = {
      id: { 'required': 'Id is required' },
      name: { 'required': 'Name is required' },

    }
    this.checkFormStatus();
  }

  getModel(): DndItem {
    var modified = deepCopy(this.model);
    extend(modified, this.form.value);
    modified.isDirty = true;
    return modified
  }


  onSave() {
    this.save.next(this.getModel());
    this.form.reset(this.form.value);
  }

  onDelete() {
    this.delete.next(this.getModel());
  }

  patchForm(change: SimpleChange) {
    const form = this.getForm();
    if (form && !form.dirty) {
      if (change.currentValue !== null && change.currentValue !== undefined) {
        form.patchValue({
          name: change.currentValue.name,
          id: change.currentValue.id,
          icon: change.currentValue.icon,
          viewElement: change.currentValue.viewElement,
          orientation: change.currentValue.orientation,
          fieldType: change.currentValue.fieldType,
          fieldLabel: change.currentValue.fieldLabel,
          fieldFormat: change.currentValue.fieldFormat,
          text: change.currentValue.text,
          imageSource: change.currentValue.imageSource,

          slidesPerView: change.currentValue.slidesPerView,
          header: change.currentValue.header,
          imageLink: change.currentValue.imageLink,
          path: change.currentValue.path,

          required: change.currentValue.required,
          validationmessage: change.currentValue.validationmessage,
          model: change.currentValue.model

        });
      }
    }
  }

  buildForm() {
    if (!this.form) {
      this.form = this._formBuilder.group({
        id: ['', Validators.required],
        name: ['', Validators.required],
        fieldType: [''],
        viewElement: [''],
        icon: [''],
        fieldLabel: [''],
        fieldFormat:[''],
        text: [''],
        imageSource: [''],
        orientation: [''],
        slidesPerView: [''],
        header: [''],
        imageLink: [''],
        path: [''],

        required: [''],
        validationmessage: [''],
        model: [''],

      });
    }
  }

}