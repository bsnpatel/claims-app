import { AfterViewInit, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ValidationErrors } from '@angular/forms';
import { Subscription } from 'rxjs';
import { titleCase } from '../utils';

export const INVALID = 'INVALID';

export class View<T> implements OnChanges, OnDestroy, AfterViewInit {

  form: FormGroup;
  formErrors: any;
  validationMessages: any;
  subscription = new Subscription();


  @Input()
  model: T;

  @Input()
  uiState: string;

  @Output()
  next = new EventEmitter();

  @Output()
  previous = new EventEmitter();

  constructor(protected _formBuilder: FormBuilder) {
  }

  buildForm() {
  }

  getFormErrors() {
    return this.formErrors;
  }

  isValid():boolean {
   return (this.getForm().status !== INVALID);
  }
  getForm(): FormGroup {
    if (!this.form) {
      this.buildForm();
    }
    return this.form;
  }

  patchForm(change) {
  }

  getModel(): T {
    return undefined;
  }

  getValidationMessages() {
    return this.validationMessages;
  }

  validateForm() {
    if (!this.getForm()) {
      return;
    }
    const form = this.getForm();
    for (const field of Object.keys(this.getFormErrors())) {
      const control = form.get(field);
      this.getFormErrors()[field] = '';

      if (control && !control.valid && control && control.errors) {
        for (const error of Object.keys(control.errors)) {
          this.getFormErrors()[field] = this.getValidationMessages()[field][error];
        }
      }
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  ngOnChanges(changes: SimpleChanges): void {
    for (const propName in changes) {
      if (propName === 'model') {
        const change = changes[propName];
        this.patchForm(change);
      }
    }
  }

  public checkFormStatus() {
    this.validateForm();
 
  }

  ngAfterViewInit(): void {
    this.checkFormStatus();
    this.subscription.add(this.getForm().valueChanges.subscribe(arg => {
      this.checkFormStatus();
    }
    ));
  }

  onNext() {
    this.next.next(this.getModel());
  }

  onPrevious() {
    this.previous.next(this.getModel());
  }

  getFormErrorList() {
    let error = new Array<String>();

    if (this.form.errors) {
      for (const field of Object.keys(this.form.controls)) {

        let fieldErrors = this.form.errors[field];

        if (fieldErrors) {
          for (const errKey of Object.keys(fieldErrors)) {
            console.log(fieldErrors[errKey]);
            error.push(fieldErrors[errKey]);
          }
        }

      }
    }
    return error;

  }
  getModelAttribute(attr){
    if (this.model){
      return this.model[attr]
    }else {
      return null
    }
  }
  handleMandatoryValidation(form: FormGroup) {

    for (const field of Object.keys(form.controls)) {
      if (form.get(field).touched) {

        if (form.get(field).enabled && !form.get(field).value) {
          if (form.get(field).validator) {
            if (form.get(field).validator.name === '' || form.get(field).validator === Validators.required) {
              //TODO evaluate for all errors to displayed at a time 
              //if(!form.errors || (form.errors && !form.errors[field])) 
              //{   
              const displayFieldName = titleCase(field.replace(/([a-z])([A-Z])/g, '$1 $2'));
              return { [field]: { 'required': displayFieldName + ' is required' } };
              //}
            }
          }
        }
      }
    }
  }
}
