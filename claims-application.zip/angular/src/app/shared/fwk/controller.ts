
import { Subscription } from "rxjs";
import { Observable } from "rxjs/internal/Observable";


export abstract class Controller<T>  {
    objects$: Observable<T[]>;
    selectedObject$: Observable<T>;
    uiState$: Observable<string>;
    error$: Observable<any>;
    subscription = new Subscription();

    constructor() { }

    abstract initialize(): void;
    abstract uiStateChange(state: string): void;

    destroy() {
        this.subscription.unsubscribe();
    }

    abstract deleteObject(obj: T): void;

    abstract editObject(obj: T): void;

    abstract addObject(obj: T): void;

    abstract selectObject(obj: T): void;

}