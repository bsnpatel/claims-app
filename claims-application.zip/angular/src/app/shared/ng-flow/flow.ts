import {FlowState} from './flow-state';
import {FlowContainer} from './flow-container';
import {Subject} from 'rxjs';


export class Flow extends FlowState {
  states: FlowState[] = [];

  nextState?: FlowState;
  defaultState?: FlowState;


  public constructor(init?: Partial<Flow>) {
    super();
    Object.assign(this, init);
    this.initialize();
  }


  initialize(): any {
    this.setDefaultState();
    this.event = new Subject();
    this.states.forEach(state => {
        state.flow = this;
        state.event.subscribe(flowevent => {
          this.event.next(flowevent);
        });
      }
    );
  }


  getState(id: String): FlowState {
    return this.states.find(state => state.id === id);

  }

  setDefaultState() {
    this.defaultState = this.states.find(state => state.isdefault === true);
  }

}
