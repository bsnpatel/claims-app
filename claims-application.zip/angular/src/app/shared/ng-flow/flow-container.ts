import {Flow} from './flow';
import {ActivatedRoute, Router} from '@angular/router';
import {FlowEvent, FlowState} from './flow-state';
import {FlowComponent} from './flow-component';
import {AfterViewInit} from '@angular/core';

export abstract class FlowContainer implements AfterViewInit {
  flow: Flow;
  currentState: FlowState;

  protected constructor(protected router: Router, protected route: ActivatedRoute) {
    this.initialize();
    this.bind();
  }

  bind() {
    this.flow.event.subscribe(flowevent => {
      console.log(flowevent);
      this.performTransition(flowevent);
    });
  }

  abstract initialize();

  abstract performTransition($event: FlowEvent);

  transition(state: FlowState) {
    console.log('routing to:'
      +  state.eventSourceUri
      + ' relative to:'
      + this.route.toString()
      +  ' full route:'
      + state.getRoute());
    this.router.navigate([ state.eventSourceUri], {relativeTo: this.route} );
  }

  onActivate($event: FlowComponent) {
    $event.flowState = this.flow.getState($event.stateId);
    this.currentState = $event.flowState;
  }

  onDeactivate($event: FlowComponent) {
    $event.flowState = undefined;
    this.currentState = $event.flowState;
  }

  transitionTo(id: String) {
    this.transition(this.flow.getState(id));
  }

  getHeader(): string {
    if (this.currentState === undefined) {
      this.currentState = this.flow.defaultState;
    }
    return this.currentState.getRoute();
  }

  ngAfterViewInit(): void {
    // this.flow.resumeInContainer(this);
  }
}
