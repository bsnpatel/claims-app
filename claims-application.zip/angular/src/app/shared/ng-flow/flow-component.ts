import {FlowState} from './flow-state';
import {OnDestroy, Input} from '@angular/core';
import {Subscription} from 'rxjs/index';

export class FlowComponent implements OnDestroy  {
  @Input()
  flowState: FlowState;
  stateId: String;
  subscription = new Subscription();

  triggerFlowEvent($event: any) {
    this.flowState.triggerFlowEvent($event);
  }

  onNext($event: any) {
    this.triggerFlowEvent('next');
  }

  onPrevious($event: any) {
    this.triggerFlowEvent('previous');
  }
  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
