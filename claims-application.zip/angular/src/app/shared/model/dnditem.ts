
export class DndItem {
    name: string;
    id: string;
    icon?: string;
    viewElement?:string;
    orientation?: string;
    fieldType?:string;
    fieldLabel?: string;
    fieldFormat?: string;
    text?:string;
    imageSource?:string;

    backgroundColor?:string;
    margin?:string;
    textAlign?:string;
    color?:string;
    fontSize?:string;

    clazz?:string;

	
	style?:string;
	
	fxLayout?:string;
    fxFlex?:string;
    fxLayoutAlign?:string;

	slidesPerView?:string ;
	header?:string ;
	imageLink?:string ;
    path?:string ;
    
	required?:string ;
	validationmessage?:string ;
	model?:string ;

    children?: DndItem[];

    constructor(options: {
        name: string,
        children?: DndItem[],
        orientation?: string

    }) {
        this.name = options.name;
        this.children = options.children || [];
        this.orientation= options.orientation ||'column';
    }


}