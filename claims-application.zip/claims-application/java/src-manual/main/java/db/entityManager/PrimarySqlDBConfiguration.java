package db.entityManager;

import java.util.HashMap;
import java.util.Map;

import javax.persistence.PersistenceContext;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.boot.orm.jpa.hibernate.SpringImplicitNamingStrategy;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Profile;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Profile("!test")          // 1
@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = "hhs.ie", entityManagerFactoryRef = "entityManager", transactionManagerRef = "transactionManager")        // 2
public class PrimarySqlDBConfiguration {
	@Autowired
	private Environment env;
     // @Bean(name = "dataSource")      // 3
     // @Primary
     // @ConfigurationProperties(prefix = "primary.datasource")
     // public DataSource mysqlDataSource() {
     //      return DataSourceBuilder.create().build();
     // }
     @Primary
     @Bean(name = "dataSource") 		// 3
     public DataSource mysqlDataSource() {

         DriverManagerDataSource dataSource = new DriverManagerDataSource();
         dataSource.setDriverClassName(env.getProperty("primary.datasource.driverClassName"));
         dataSource.setUrl(env.getProperty("primary.datasource.jdbcUrl"));
         dataSource.setUsername(env.getProperty("primary.datasource.username"));
         dataSource.setPassword(env.getProperty("primary.datasource.password"));
         dataSource.setSchema(env.getProperty("primary.datasource.schema"));
         return dataSource;

     }
    @PersistenceContext(unitName = "primary")   // 4
     @Primary
     @Bean(name = "entityManager")
     public LocalContainerEntityManagerFactoryBean mySqlEntityManagerFactory(EntityManagerFactoryBuilder builder) {
          return builder.dataSource(mysqlDataSource()).persistenceUnit("primary").properties(jpaProperties())
                    .packages("hhs.ie").build();
      }
     private Map<String, Object> jpaProperties() {
          Map<String, Object> props = new HashMap<>();
          props.put("hibernate.ejb.naming_strategy", new SpringImplicitNamingStrategy());
          return props;
      }
}