package superbolt.util.dao;

import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import io.jsondb.JsonDBTemplate;
import io.jsondb.crypto.Default1Cipher;
import io.jsondb.crypto.ICipher;

@Component
public class DataManager<T> {
	@Value("${db.location}") protected String dbLocation;
//	@Autowired
//	BoltFileSystemAccess boltFileSystemAccess;
	// Actual location on disk for database files, process should have read-write
	// permissions to this folder
//	String dbFilesLocation;
	String baseScanPackage;
	JsonDBTemplate jsonDBTemplate;
	boolean initialized = false;
//	DataManager() {
//		initialize( "superbolt.util.model");
//	}

	void initialize(String baseScanPackage) {
//		this.dbFilesLocation = dbFilesLocation;
		System.out.println("baseScanPackage"+baseScanPackage);
		// Java package name where POJO's are present
		this.baseScanPackage = baseScanPackage;
		// Optionally a Cipher object if you need Encryption
		ICipher cipher;
		try {
			cipher = new Default1Cipher("1r8+24pibarAWgS85/Heeg==");
			jsonDBTemplate = new JsonDBTemplate(dbLocation, baseScanPackage, cipher);
		} catch (GeneralSecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public T save(T obj) {
		if (!initialized) {
			initialize(obj.getClass().getPackage().getName());
			System.out.println("Package : " + obj.getClass().getPackage().getName());
//			initialized = true;
		}
		if (!jsonDBTemplate.collectionExists(obj.getClass().getSimpleName()))
			jsonDBTemplate.createCollection(obj.getClass().getSimpleName());
		else {
//			jsonDBTemplate.reloadCollection(obj.getClass().getName());
			;
		}
		jsonDBTemplate.insert(obj);
		return obj;
	}

	public Optional<T> findById(String id, Class<T> c) {
		if (!initialized) {
			initialize(c.getPackage().getName());
//			initialized = true;
		}
		if (jsonDBTemplate.collectionExists(c.getSimpleName())) {
//			jsonDBTemplate.reloadCollection(c.getName());
			;
			T obj = jsonDBTemplate.findById(id, c);

			if (obj != null) {
				return Optional.of(obj);
			}
		}
		return Optional.empty();

	}

	public T findById(String id, String pkg, String className) {
		if (!initialized) {
			initialize(pkg);
//			initialized = true;
		}
		if (jsonDBTemplate.collectionExists(className)) {
//			jsonDBTemplate.reloadCollection(c.getName());
			T obj = jsonDBTemplate.findById(id, className);

			return obj;
		}
		return null;
//
//			if (obj != null) {
//				return Optional.of(obj);
//			}
//		}
//		return Optional.empty();

	}

	public List<T> findAll(Class<T> c) {
		if (!initialized) {
			initialize(c.getPackage().getName());
//			initialized = true;
		}
		if (jsonDBTemplate.collectionExists(c.getSimpleName())) {
//			jsonDBTemplate.reloadCollection(c.getName());
			return jsonDBTemplate.findAll(c);
		}

		return new ArrayList<T>();
	}

	public List<T> findAll(String pkg, String className) {
		if (!initialized) {
			initialize(pkg);
//			initialized = true;
		}
		if (jsonDBTemplate.collectionExists(className)) {
//			jsonDBTemplate.reloadCollection(c.getName());
			return jsonDBTemplate.findAll(className);
		}

		return new ArrayList<T>();
	}

	public List<T> find(String query, String pkg, String className) {
		if (!initialized) {
			initialize(pkg);
//			initialized = true;
		}
		if (jsonDBTemplate.collectionExists(className)) {
//			jsonDBTemplate.reloadCollection(c.getName());
			return jsonDBTemplate.find(query, className);
		}

		return new ArrayList<T>();
	}

	public List<T> find(String query, Class<T> c) {
		if (!initialized) {
			initialize(c.getPackage().getName());
//			initialized = true;
		}
		if (jsonDBTemplate.collectionExists(c.getSimpleName())) {
//			jsonDBTemplate.reloadCollection(c.getName());
			return jsonDBTemplate.find(query, c);
		}

		return new ArrayList<T>();
	}

	public T delete(T obj, Class<T> c) {
		if (!initialized) {
			initialize(c.getPackage().getName());
//			initialized = true;
		}
		if (jsonDBTemplate.collectionExists(c.getSimpleName())) {
//			jsonDBTemplate.reloadCollection(c.getName());
			jsonDBTemplate.remove(obj, c);
		}
		return obj;

	}

	public T delete(String id, String pkg, String className) {
		if (!initialized) {
			initialize(pkg);
//			initialized = true;
		}
		T obj = findById(id, pkg, className);
		if (obj!=null && jsonDBTemplate.collectionExists(className)) {
//			jsonDBTemplate.reloadCollection(c.getName());
			jsonDBTemplate.remove(obj, className);
		}
		return obj;

	}
}
