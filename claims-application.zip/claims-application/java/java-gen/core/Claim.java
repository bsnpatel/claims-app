package core;
import java.sql.Date;
import java.sql.Timestamp;
import java.math.BigInteger;
import java.math.BigDecimal;
import java.util.List;
import com.google.common.collect.Lists;

import core.ClaimLine;
import io.jsondb.annotation.Document;
import io.jsondb.annotation.Id;
@Document(collection = "Claim", schemaVersion = "1.0")
public class Claim {
	
	boolean isDirty;	
	
	@Id
	String id;
	String memberId;
	String memberFirstName;
	String memberInitial;
	String memberLastName;
	Integer billTaxId;
	Integer billNpi;
	Integer renderingTaxId;
	Integer renderingNpi;
	String diagCd1;
	String diagCd2;
	String diagCd3;
	String diagCd4;
	String diagCd5;
	String totalCharge;
	Date fromDate;
	Date thruDate;
	ClaimLine claimLine;
	String claimType;
	public Claim() {
		this.id = "";
		this.memberId = "";
		this.memberFirstName = "";
		this.memberInitial = "";
		this.memberLastName = "";
		this.billTaxId = 0;
		this.billNpi = 0;
		this.renderingTaxId = 0;
		this.renderingNpi = 0;
		this.diagCd1 = "";
		this.diagCd2 = "";
		this.diagCd3 = "";
		this.diagCd4 = "";
		this.diagCd5 = "";
		this.totalCharge = "";
		this.fromDate =  null;
		this.thruDate =  null;
		this.claimType =  "";
	}
	public String getId() {
		return this.id;
	}
					
	public void setId(String id) {
		this.id=id;
	}
	public String getMemberId() {
		return this.memberId;
	}
					
	public void setMemberId(String memberId) {
		this.memberId=memberId;
	}
	public String getMemberFirstName() {
		return this.memberFirstName;
	}
					
	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName=memberFirstName;
	}
	public String getMemberInitial() {
		return this.memberInitial;
	}
					
	public void setMemberInitial(String memberInitial) {
		this.memberInitial=memberInitial;
	}
	public String getMemberLastName() {
		return this.memberLastName;
	}
					
	public void setMemberLastName(String memberLastName) {
		this.memberLastName=memberLastName;
	}
	public Integer getBillTaxId() {
		return this.billTaxId;
	}
					
	public void setBillTaxId(Integer billTaxId) {
		this.billTaxId=billTaxId;
	}
	public Integer getBillNpi() {
		return this.billNpi;
	}
					
	public void setBillNpi(Integer billNpi) {
		this.billNpi=billNpi;
	}
	public Integer getRenderingTaxId() {
		return this.renderingTaxId;
	}
					
	public void setRenderingTaxId(Integer renderingTaxId) {
		this.renderingTaxId=renderingTaxId;
	}
	public Integer getRenderingNpi() {
		return this.renderingNpi;
	}
					
	public void setRenderingNpi(Integer renderingNpi) {
		this.renderingNpi=renderingNpi;
	}
	public String getDiagCd1() {
		return this.diagCd1;
	}
					
	public void setDiagCd1(String diagCd1) {
		this.diagCd1=diagCd1;
	}
	public String getDiagCd2() {
		return this.diagCd2;
	}
					
	public void setDiagCd2(String diagCd2) {
		this.diagCd2=diagCd2;
	}
	public String getDiagCd3() {
		return this.diagCd3;
	}
					
	public void setDiagCd3(String diagCd3) {
		this.diagCd3=diagCd3;
	}
	public String getDiagCd4() {
		return this.diagCd4;
	}
					
	public void setDiagCd4(String diagCd4) {
		this.diagCd4=diagCd4;
	}
	public String getDiagCd5() {
		return this.diagCd5;
	}
					
	public void setDiagCd5(String diagCd5) {
		this.diagCd5=diagCd5;
	}
	public String getTotalCharge() {
		return this.totalCharge;
	}
					
	public void setTotalCharge(String totalCharge) {
		this.totalCharge=totalCharge;
	}
	public Date getFromDate() {
		return this.fromDate;
	}
					
	public void setFromDate(Date fromDate) {
		// this.fromDate=fromDate;
		this.fromDate = Date.valueOf(java.time.LocalDate.now());
	}
	public Date getThruDate() {
		return this.thruDate;
	}
					
	public void setThruDate(Date thruDate) {
		// this.thruDate=thruDate;
		this.thruDate = Date.valueOf(java.time.LocalDate.now());
	}
	public ClaimLine getClaimLine() {
		return this.claimLine;
	}
	
	public void setClaimLine(ClaimLine claimLine) {
		this.claimLine=claimLine;
	}
	public String getClaimType() {
		return this.claimType;
	}
	
	public void setClaimType(String claimType) {
		this.claimType=claimType;
	}
	
}
