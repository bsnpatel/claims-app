export const environment = {
  production: true,
  envName: 'prod',
  apiEndpoint: '/api',
  brokerURL: 'wss://172.30.168.5:8000/websocket'
};
