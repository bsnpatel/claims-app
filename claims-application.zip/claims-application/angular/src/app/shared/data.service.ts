import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';


@Injectable()
export class DataService {

  messageSource = new BehaviorSubject<boolean>(false);
 
  constructor() { }

  changeMessage(message: boolean) {
    this.messageSource.next(message);
  }
}
