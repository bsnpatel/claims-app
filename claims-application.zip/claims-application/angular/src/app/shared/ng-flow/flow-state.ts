import {Subject} from 'rxjs/index';
import {Flow} from './flow';

export class FlowEvent {
  state: FlowState;
  value: any;

  public constructor(value: any) {
    this.value = value;
  }
}

export class FlowState {

  id: string;
  name: string;
  eventSourceUri: string;
  isdefault: boolean;

  flow: Flow;
  event: Subject<FlowEvent>;

  public constructor(init ?: Partial<FlowState>) {
    Object.assign(this, init);
    this.event = new Subject();

  }

  getRoute(): string {
    const route: string = (this.flow) ? (this.flow.getRoute() + '/' + this.eventSourceUri) : ('/' + this.eventSourceUri );
    return route;

  }

  triggerFlowEvent($event: any) {
    const t = new FlowEvent($event);
    t.state = this;
    this.event.next(t);
  }
}
