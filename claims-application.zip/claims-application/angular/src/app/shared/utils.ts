import { Params, RouterStateSnapshot } from '@angular/router';
import { RouterReducerState, RouterStateSerializer } from '@ngrx/router-store';

export interface RouterStateUrl {
  url: string;
  params: Params;
  queryParams: Params;
}

export interface State {
  router: RouterReducerState<RouterStateUrl>;
}

export class CustomSerializer implements RouterStateSerializer<RouterStateUrl> {
  serialize(routerState: RouterStateSnapshot): RouterStateUrl {
    let route = routerState.root;

    while (route.firstChild) {
      route = route.firstChild;
    }

    const { url, root: { queryParams } } = routerState;
    const { params } = route;

    // Only return an object including the URL, params and query params
    // instead of the entire snapshot
    return { url, params, queryParams };
  }
}
export function makeid(length) {
  var result = '';
  var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  var charactersLength = characters.length;
  for (var i = 0; i < length; i++) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
  }
  return result;
}
export function extend(obj, src) {
  if (src !== null && obj !== null) {
    Object.keys(src).forEach(function (key) {
      if (src[key] instanceof Object) {
        extend(obj[key], src[key])
      } else {
        obj[key] = src[key];
      }
    });
  }
  return obj;
}
export function deepCopy(obj) {
  if (obj !== null && obj!==undefined) {
    return JSON.parse(JSON.stringify(obj));
  } else {
    return null
  }
}

export function upperCase(str) {
  return str.toUpperCase();
}
export function titleCase(str) {
  const firstLetterRx = /(^|\s)[a-z]/g;
  return str.replace(firstLetterRx, upperCase);
}