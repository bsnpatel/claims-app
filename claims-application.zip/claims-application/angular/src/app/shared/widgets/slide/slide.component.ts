import { Component, Input } from "@angular/core";

@Component({
    selector: 'bolt-slide',
    templateUrl: './slide.component.html',
    styleUrls: ['./slide.component.scss']
  })
  export class SlideComponent  {
    @Input()
    imageSource: string;

    @Input()
    header: string;

    @Input()
    description: string;

    viewMore(){

    }
  }