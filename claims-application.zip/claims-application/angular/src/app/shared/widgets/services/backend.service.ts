import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, from, Observable } from 'rxjs';

import { EditorResource } from '../models/resource.model';

@Injectable()
export class BoltResourceService {
	selection: string;
	selectedResource: BehaviorSubject<EditorResource> = new BehaviorSubject({uri:'',code:'',language:''})

	resourceList: BehaviorSubject<string[]> = new BehaviorSubject([
		"/app/BoltApplication.sml",
		"/app/BoltHomePage.sml"
	])

	resources: { [uri: string]: EditorResource } = {
		"/app/BoltApplication.sml": {
			uri: "inmemory:/app/BoltApplication.sml",
			language: "sbs",
			code:`<%  bolt.lang.*;
			bolt.lang.BoltTags.*;
			superbolt.core.*;
			superbolt.app.*;
			%>
			<bolt-application name = 'BOLT Application' >
			  <bolt-nav>
				<bolt-tab path='home' label='Home' ></bolt-tab>
				<bolt-tab path='projects' label='Projects' ></bolt-tab>
				<bolt-tab path='requirements' label='Requirements' ></bolt-tab>
				<bolt-tab path='planning' label='Planning' ></bolt-tab>
				<bolt-tab path='workspace' label='Development' ></bolt-tab>
				<bolt-tab path='workspace' label='Testing' ></bolt-tab>
				<bolt-tab path='workspace' label='Operations' ></bolt-tab>
			  </bolt-nav>
			</bolt-application>
			`
		},

		"/app/BoltHomePage.sml": {
			uri: "inmemory:/app/BoltHomePage.sml",
			language: "sbs",
			code:`<%  bolt.lang.BoltTags.*;
			bolt.lang.HtmlTags.*;
			superbolt.app.*;
			%>
			<bolt-page name = 'Home' >
			   <bolt-carousel slidesPerView = '3' >
				<bolt-slide imageSource = '/assets/images/Cash.jpg' header='Cash' >
				Cash Benefits Description 
				</bolt-slide>
				<bolt-slide imageSource  = '/assets/images/Child Care.jpg' header='Child Care' > 
				Child Care Benefits Description
				</bolt-slide>
				<bolt-slide imageSource  = '/assets/images/Medical.jpg' header='Medical' >
				Medical Benefits Description
				</bolt-slide>
				<bolt-slide imageSource = '/assets/images/SNAP.jpg' header='SNAP' > SNAP Description</bolt-slide>
			   </bolt-carousel>
			   <bolt-layout layoutType = "row">
					<bolt-paragraph>
						<bolt-paragraph>Configuration Over Coding</bolt-paragraph>
						<bolt-paragraph>Human services transbolt-formation, today</bolt-paragraph>
						<bolt-paragraph>Build, with less effort</bolt-paragraph>
						<bolt-paragraph>Deliver, with quality</bolt-paragraph>
						<bolt-paragraph>Repeat, with consistency</bolt-paragraph>
					</bolt-paragraph>
					 <bolt-image imageLink = "https://deloitte.com" imageSource  = '/assets/images/Laptop_Demo3.png'>Laptop</bolt-image>
			   </bolt-layout>
				<bolt-layout layoutType = "row">
					<bolt-paragraph>
						<bolt-paragraph>Our Approach</bolt-paragraph>
						<bolt-paragraph>
							<p>NextGen Bolt is an industrialized approach to building applications, 
									derived from the concepts of Software Product Line Engineering and Domain Engineering.</p>
							<p>It is a vendor-independent, Deloitte-proprietary programming language that enables us to generate our 
									solutions for a variety of destination technology stacks without major refactoring.</p>
							<p>We begin by harvesting proven code and assets and abstract the core business from the technology stack 
									through reusable templates and patterns</p>
						</bolt-paragraph>
					</bolt-paragraph>
					<bolt-image imageSource = '/assets/images/HowitsMade.png' >How its Made</bolt-image>
			   </bolt-layout>
			</bolt-page>
			`
		}
	};

	constructor(private http: HttpClient) {
	}

	getSelectedResource(): Observable<EditorResource> {
		return this.selectedResource;
	}
	getResourceList(): Observable<string[]> {
		return this.resourceList;
	}

	getSelection(){
		return this.selection
	}
	
	setSelection(uri:string) {
		this.selection = uri;
		this.selectedResource.next(this.resources[this.selection])
	}

}
