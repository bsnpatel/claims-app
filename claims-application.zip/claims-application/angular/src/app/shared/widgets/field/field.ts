
import { Component, Input, OnInit, AfterViewInit, ViewChild, SimpleChanges, SimpleChange, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup,Validators,FormControl } from '@angular/forms';
import {Subscription, Observable} from "rxjs";

export class FieldComponent implements OnInit, OnChanges, AfterViewInit {
    formErrors: any = {};
    messages: any = {};
    subscription = new Subscription();
    isValid: boolean;
    value: any = {}

    @Input()
    form: FormGroup;

    @Input()
    displayWhen: boolean=true;

    @Input()
    id: string;
    
    @Input()
    name: string;

    @Input()
    model: any;

    @Input()
    label: string;

    @Input()
    required: boolean;

    @Input()
    validationmessage: string;

    @Input()
    format: string;

    constructor(protected _formBuilder: FormBuilder) {
        this.form = new FormGroup({});
    }

    ngOnInit() {
        this.formErrors[this.id] = '';
        this.messages[this.id] = { 
        'required': this.validationmessage,
        'pattern': this.label +' should be in ' + this.format +' format' };

        this.checkFormStatus();
    }

    ngOnChanges(changes: SimpleChanges): void {
        if (changes['form']) {
            this.buildForm(changes['form']);
            if (changes['model']) {
                this.patchForm(changes['model']);
            }
        }
    }

    patchForm(change: SimpleChange) {
        if (this.form && !this.form.dirty) {
            if (change.currentValue !== null && change.currentValue !== undefined) {
                this.value[this.id] = change.currentValue;
                this.form.patchValue(this.value);
            }
        }
    }

    buildForm(change: SimpleChange) {
        this.form = change.currentValue;
        if (this.required){
             this.form.addControl(this.id, new FormControl('', Validators.required));
        }else {
            this.form.addControl(this.id, new FormControl(''));
        }
    }

    public checkFormStatus() {
        this.validateForm();
        this.isValid = (this.form.status !== 'INVALID');
    }


    ngAfterViewInit(): void {
        this.checkFormStatus();
        this.subscription.add(this.form.valueChanges.subscribe(arg => {
            this.checkFormStatus();
        }));
    }
    validateForm() {
        if (!this.form) {
            return;
        }
        for (const field of Object.keys(this.formErrors)) {
            const control = this.form.get(field);
            this.formErrors[field] = '';
            if (control && !control.valid  && control.errors)  {
                for (const error of Object.keys(control.errors)) {
                    this.formErrors[field] = this.messages[field][error];
                }
            }
        }
    }
    hasErrors() {
        return this.formErrors[this.id]
            && this.form.controls[this.id].touched
    }
    ngOnDestroy(): void {
        this.subscription.unsubscribe();
    }
    getErrors() {
        return this.formErrors[this.id]
    }
}