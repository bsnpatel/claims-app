import { CdkDragDrop } from "@angular/cdk/drag-drop";
import { ChangeDetectionStrategy, Component, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from "@angular/core";
import { DndItem } from "../../model/dnditem";
import { PaletteItem } from "../../model/paletteitem";

@Component({
    selector: 'bolt-palette',
    templateUrl: './palette.component.html',
    styleUrls: ['./palette.component.scss'],
    encapsulation: ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
  })
  export class PaletteComponent implements OnInit, OnChanges {
    ngOnChanges(changes: SimpleChanges): void {
      console.log('onChanges')
      console.log(this.paletteItems)
      console.log(this.connectedDropListsIds)
    }
 
    @Input()
     paletteItems: PaletteItem[];

    @Input()
     connectedDropListsIds: String[];

    @Output()
    dropEvent: CdkDragDrop<DndItem>

   /*  handleDragStart(event) {
      console.log("drag start " + event.target)
      
      event.dataTransfer.setData("palletTag", event.target.getElementsByTagName("h5")[0].innerText);


    } */

    dragStart(event,item: PaletteItem) {
      console.log("drag start " + event.target)
      
      event.dataTransfer.setData("palletTag", JSON.stringify(item));


    }
    
    ngOnInit(): void {
       console.log(this.paletteItems)
       console.log(this.connectedDropListsIds)

       


     //  document.addEventListener("dragstart", this.handleDragStart);
       // While dragging the p element, change the color of the output text
  document.addEventListener("drag", function (event) {
    console.log("drag");
    // document.getElementById("demo").style.color = "red";
  });

  // Output some text when finished dragging the p element and reset the opacity
  document.addEventListener("dragend", function (event) {
    console.log("dragend");
  //  document.getElementById("demo").innerHTML = "Finished dragging the p element.";
   // event.target.style.opacity = "1";
  });


  /* ----------------- Events fired on the drop target ----------------- */

  // When the draggable p element enters the droptarget, change the DIVS's border style
  document.addEventListener("dragenter", function (event) {
    console.log("dragenter");
   // if (event.target.className == "droptarget") {
     // event.target.style.border = "3px dotted red";
    //}
  });

  // By default, data/elements cannot be dropped in other elements. To allow a drop, we must prevent the default handling of the element
  document.addEventListener("dragover", function (event) {
    console.log("dragover");
    event.preventDefault();
  });

  // When the draggable p element leaves the droptarget, reset the DIVS's border style
  document.addEventListener("dragleave", function (event) {
    console.log("dragleave");
  //  if (event.target.className == "droptarget") {
   //   event.target.style.border = "";
    //}
  });
    }
 
    onDragDrop(event: CdkDragDrop<DndItem>) {
      console.log("Palette method Called")
      this.dropEvent = event;

  }
    drop(ev) {
      console.log("ev"+ev);
     ev.preventDefault();
     var data = ev.dataTransfer.getData("text");
     //  ev.target.appendChild(document.getElementById(data));
     let el = document.createElement("div")
     el.innerHTML = this.getTemplate(data);
     ev.target.appendChild(el);
     
     }
   
   getTemplate(tag) {
     switch (tag) {
       case "text": {
       return `<input  draggable="true" type="text"/>`
       }
       case "layout": {
       return `<div  draggable="true" > Add Element</div>`
       }
       case "dropdown": {
       return `<select  draggable="true" ></select>`
       }
     };
     return "";
     }
    
  }