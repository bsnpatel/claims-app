import { CommonModule } from '@angular/common';
import { ModuleWithProviders, NgModule } from '@angular/core';

import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { MaterialModule } from '../material/material.module';
import { CarouselComponent } from './carousel/carousel.component';
import { SwiperModule } from 'ngx-swiper-wrapper';
import { DeleteDialog } from './delete-dialog/delete-dialog.component';
import { TextComponent } from './text/text.component';
import { RadioComponent } from './radio/radio.component';
import { LabelComponent } from './label/label.component';
import { DropdownComponent } from './drop-down/drop-down.component';
import { UiStateComponent } from './uistate/uistate.component';
import { DateComponent } from './date/date.component';
import { FormComponent } from './form/form.component';
import { FilepickerComponent } from './filepicker/filepicker.component';
import { SlideComponent } from './slide/slide.component';
import { ColumnComponent } from './column-layout/column-component';


import { ImageComponent } from './image/image.component';
import { LayoutComponent } from './layout/layout.component';
import { PageComponent } from './page/page.component';
import { ParagraphComponent } from './paragraph/paragraph.component';
import { TabComponent } from './tab/tab.component';
import { TopNavComponent } from './nav/nav.component';
import { MenuComponent } from './menu/menu.component';
import { MenuItemComponent } from './menuitem/menuitem.component';
import { DragDropItemComponent } from './dnd-item/dnd-item.component';
import { PaletteComponent } from './palette/palette.component';
import { DnDWidgetComponent } from './dnd-widget/dnd-widget-component';
import { CodeEditorComponent } from './code-editor/code-editor.component';
import { CodeEditorWrapperComponent } from './code-editor/editor-wrapper.component';
import { ExplorerComponent } from './explorer/explorer.component';
import { MonacoEditorComponent } from './monaco-editor/monaco-editor.component';
import { BoltResourceService } from './services/backend.service';
import { DndItemService } from './dnd-item/dnd-item.service';
import { InjectableRxStompConfig, RxStompService, rxStompServiceFactory } from '@stomp/ng2-stompjs';
import { myRxStompConfig } from 'src/app/rx-stomp.config';
import { StompMessagesComponent } from './messages/messages.component';
import { ItemEditorComponent } from './item-editor/item-editor.component';
import { StyleEditorComponent } from './style-editor/style-editor.component';
import { UIEditorComponent } from './ui-editor/ui-editor.component';
import { StyleService } from './services/style.service';
import { DndModule } from 'ngx-drag-drop';
import { ListingComponent } from './listing/listing.component';
import { LibModule } from '@usitsdasdesign/dds-ng';
import { PaginationComponent } from './pagination/pagination.component';

@NgModule({
  imports: [
    CommonModule,
    MaterialModule,
    FlexLayoutModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    SwiperModule,
    DndModule,
    LibModule
  ],
  declarations: [
    CarouselComponent,
    DeleteDialog,
    TextComponent,
    RadioComponent,
    LabelComponent,
    UiStateComponent,
    DropdownComponent,
    DateComponent,
    FormComponent,
    FilepickerComponent,
    SlideComponent,
    ImageComponent,
    LayoutComponent,
    PageComponent,
    ParagraphComponent,
    TopNavComponent,
    TabComponent,
    ColumnComponent,
    DragDropItemComponent,
    DnDWidgetComponent,
    MenuComponent,
    MenuItemComponent,
    PaletteComponent,
    MonacoEditorComponent,
    CodeEditorComponent,
    CodeEditorWrapperComponent,
    ExplorerComponent,
    StompMessagesComponent,
    ItemEditorComponent,
    StyleEditorComponent,
    UIEditorComponent,
    ListingComponent,
    PaginationComponent
    //  TopNavigationComponent
  ],

  exports: [
    SwiperModule,
    DndModule,
    CarouselComponent,
    DeleteDialog,
    TextComponent,
    RadioComponent,
    LabelComponent,
    UiStateComponent,
    DropdownComponent,
    DateComponent,
    FormComponent,
    FilepickerComponent,
    SlideComponent,
    ImageComponent,
    LayoutComponent,
    PageComponent,
    ParagraphComponent,
    TopNavComponent,
    TabComponent,
    ColumnComponent,
    DragDropItemComponent,
    DnDWidgetComponent,
    MenuComponent,
    MenuItemComponent,
    PaletteComponent,
    MonacoEditorComponent,
    CodeEditorComponent,
    CodeEditorWrapperComponent,
    ExplorerComponent,
    StompMessagesComponent,
    ItemEditorComponent,
    StyleEditorComponent,
    UIEditorComponent,
    ListingComponent,
    PaginationComponent

    //  TopNavigationComponent
  ],

  entryComponents: [DeleteDialog],

  providers: [DndItemService, BoltResourceService,StyleService,
    {
			provide: InjectableRxStompConfig,
			useValue: myRxStompConfig,
		},
		{
			provide: RxStompService,
			useFactory: rxStompServiceFactory,
			deps: [InjectableRxStompConfig],
    },
  ]
})
export class WidgetsModule {
  static forRoot(): ModuleWithProviders<WidgetsModule> {
    return {
      ngModule: WidgetsModule

    };
  }
}
