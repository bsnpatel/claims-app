/// <reference path="../../../../../node_modules/monaco-editor/monaco.d.ts" />
import { Component, Input, AfterViewInit, ElementRef, ViewChild, forwardRef, NgZone, Output, EventEmitter, OnChanges, OnDestroy } from '@angular/core';
import { NG_VALUE_ACCESSOR } from '@angular/forms';
import { fromEvent, Subscription } from 'rxjs';
import { EditorConfigService } from '../services/editor-config.service';

let loadedMonaco = false;
let loadPromise: Promise<void>;

@Component({
  selector: 'monaco-editor',
  template: '<div class="editor-container" #editorContainer></div>',
  styles: [`
    :host {
      display: block;
      height: 400px;
    }
    .editor-container {
      width: 100%;
      height: 100%;
    }
  `],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => EditorConfigService),
      multi: true
    }
  ]
})
export class MonacoEditorComponent implements AfterViewInit, OnChanges, OnDestroy {

  @ViewChild('editorContainer') _editorContainer: ElementRef;

  @Input() code = '';
  @Output() codeChange = new EventEmitter<String>();
  @Output() onInit = new EventEmitter<any>();

  @Input() language = '';
  @Input() uri = '';


  protected _editor: monaco.editor.IStandaloneCodeEditor;
  protected _windowResizeSubscription: Subscription;

  constructor(private zone: NgZone, private configService: EditorConfigService) { }


  ngAfterViewInit() {
    if (loadedMonaco) {
      // Wait until monaco editor is available
      loadPromise.then(() => {
        this.initMonaco();
      });
    } else {
      loadedMonaco = true;
      loadPromise = new Promise<void>((resolve: any) => {
        if (typeof ((<any>window).monaco) === 'object') {
          resolve();
          return;
        }
        const onAmdLoader: any = () => {
          // Load monaco
          (<any>window).require.config({ paths: { 'vs': 'assets/monaco/vs' } });

          (<any>window).require(['vs/editor/editor.main'], () => {
            this.initMonaco();
            resolve();
          });
        };

        // Load AMD loader if necessary
        if (!(<any>window).require) {
          const loaderScript: HTMLScriptElement = document.createElement('script');
          loaderScript.type = 'text/javascript';
          loaderScript.src = 'assets/monaco/vs/loader.js';
          loaderScript.addEventListener('load', onAmdLoader);
          document.body.appendChild(loaderScript);
        } else {
          onAmdLoader();
        }
      });
    }
  }

  initMonaco(): void {
    // configure the monaco editor to understand custom language - sbs
    monaco.languages.register(this.configService.getsbsExtensionPoint());
    monaco.languages.setMonarchTokensProvider(this.language, this.configService.getsbsTokenProviders());
    // monaco.editor.defineTheme('sbsTheme', this.configService.getsbsTheme());   
    // add  custom theme here

    const onModelAdd = (model: monaco.editor.IModel): void => {
      let handle: any;
      model.onDidChangeContent((e: monaco.editor.IModelContentChangedEvent) => {
        // here we are Debouncing the user changes, so everytime a new change is done, we wait 500ms
        // otherwise if the user is still typing, we cancel the
        clearTimeout(handle);
        handle = setTimeout(() => {
           this.codeChange.emit(model.getValue())
        }, 500);
      });
    };
    monaco.editor.onDidCreateModel(onModelAdd);


    var model: monaco.editor.ITextModel = monaco.editor.getModel(monaco.Uri.parse(this.uri));
    if (model == null) {
      model = monaco.editor.createModel(this.code, this.language, monaco.Uri.parse(this.uri))
    }

    if (!this._editor) {
      this._editor = monaco.editor.create(this._editorContainer.nativeElement, {
        value: this.code,
        language: this.language,
        theme: 'vs',
        model: model
      });
    } else {
      this._editor.setModel(model);
    }

    // refresh layout on resize event.
    if (this._windowResizeSubscription) {
      this._windowResizeSubscription.unsubscribe();
    }
    this._windowResizeSubscription = fromEvent(window, 'resize').subscribe(() => this._editor.layout());
    this.onInit.emit(this._editor);
  }

  // supports two-way binding
  ngOnChanges() {
    if (this._editor) {
      var model = monaco.editor.getModel(monaco.Uri.parse(this.uri));
      if (model == null) {
        model = monaco.editor.createModel(this.code, this.language, monaco.Uri.parse(this.uri))
      }
      this._editor.setModel(model);
    }
  }

  ngOnDestroy() {
    if (this._windowResizeSubscription) {
      this._windowResizeSubscription.unsubscribe();
    }
    if (this._editor) {
      this._editor.dispose();
      this._editor = undefined;
    }
  }
}
