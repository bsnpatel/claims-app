import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, Output, SimpleChanges, ViewChild, ViewEncapsulation } from "@angular/core";
import { MatSidenav } from "@angular/material/sidenav";
import { MatSnackBar } from "@angular/material/snack-bar";
import { DndDropEvent, DropEffect } from "ngx-drag-drop";
import { DndItem } from "src/app/shared/model/dnditem";
import { PaletteItem } from "src/app/shared/model/paletteitem";
import { DndItemService } from "src/app/shared/widgets/dnd-item/dnd-item.service";
import { deepCopy } from "../../utils";

@Component({
	selector: 'bolt-ui-editor',
	templateUrl: './ui-editor.component.html',
	styleUrls: ['./ui-editor.component.scss'],
	encapsulation: ViewEncapsulation.None,
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class UIEditorComponent implements OnChanges {
	@ViewChild(MatSidenav) sideNav2: MatSidenav;
	@Input()
	paletteItems: PaletteItem[];

	@Input()
	parentItem: DndItem

	@Input()
	selectedItem: DndItem

	@Output() saveAction = new EventEmitter();


	constructor(
		private service: DndItemService, private snackBarService: MatSnackBar,) {
	}
	ngOnChanges(changes: SimpleChanges): void {

	}
	private currentDraggableEvent: DragEvent;
	private currentDragEffectMsg: string;


	onDragStart(event: DragEvent) {

		this.currentDragEffectMsg = "";
		this.currentDraggableEvent = event;

		this.snackBarService.dismiss();
		this.snackBarService.open("Drag started!", undefined, { duration: 2000 });
	}

	onDragged(item: any, list: any[], effect: DropEffect) {

		this.currentDragEffectMsg = `Drag ended with effect "${effect}"!`;

		if (effect === "move") {

			const index = list.indexOf(item);
			list.splice(index, 1);
			//this.service.setParentItem(this.parentItem)
		}
	}



	onDragEnd(event: DragEvent) {

		this.currentDraggableEvent = event;
		this.snackBarService.dismiss();
		this.snackBarService.open(this.currentDragEffectMsg || `Drag ended!`, undefined, { duration: 2000 });
	}

	onDrop(event: DndDropEvent, list?: any[]) {

		if (list
			&& (event.dropEffect === "copy"
				|| event.dropEffect === "move")) {
			let index = event.index;
			if (typeof index === "undefined") {
				index = list.length;
			}
			if (event.dropEffect === "move") {
				list.splice(index, 0, event.data);
			}else {
				
				let data = deepCopy(event.data)
				data.id = data.fieldType + '_' + this.service.nextId()
				list.splice(index, 0, data);
			}
			//this.service.setParentItem(this.parentItem)
		}
	}

	public onDelete(event: any) {
		this.service.remove(event)
	}

	public onSelect(item: any): void {
		this.service.setSelectedItem(item);
	}

	public onSave(item: any): void {
		this.service.save(item)
	}



	style(item: DndItem) {
		return this.service.style(item)
	}


	clazz(item: DndItem) {
		if (item.clazz) {
			return this.service.clazz(item)
		} else { return '' }
	}

	onSaveAll() {
		this.saveAction.emit(this.parentItem);
	}
	public onEdit(event: any) {
		this.service.setSelectedItem(event);
	}
	isNestable(item: DndItem) {
		return (item.fieldType === 'bolt-page')
			|| (item.fieldType === 'bolt-form')
			|| (item.fieldType === 'editable-placeholder')
			|| (item.fieldType === 'bolt-component')
			|| (item.fieldType === 'bolt-list')
			|| (item.fieldType === 'bolt-layout')
			|| (item.fieldType === 'bolt-carousel')
			|| (item.fieldType === 'bolt-nav')
			|| (item.fieldType === 'bolt-application')
	}

	onClick($event, item) {


		this.service.setSelectedItem(item);
		let nested = $event.srcElement.parentElement.querySelector(".nested")
		if (nested) {
			nested.classList.toggle("active");
			$event.srcElement.classList.toggle("caret-down");
		}
		if ($event.srcElement.classList.contains("leaf")) {


			//this.editAction.emit(this.model.find(x => x.uri === path));
		}
	}
}
