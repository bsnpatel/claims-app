import { Component, Input } from "@angular/core";
import { BehaviorSubject } from "rxjs";

@Component({
  selector: 'bolt-tab',
  templateUrl: './tab.component.html',
  styleUrls: ['./tab.component.scss']
})
export class TabComponent {
  @Input()
  label: string;

  @Input()
  path: string;

  @Input()
  active: string;

  topNav: any;

  onClick($event) {
    this.topNav.clearAll();
    this.active = "true"

  }
}