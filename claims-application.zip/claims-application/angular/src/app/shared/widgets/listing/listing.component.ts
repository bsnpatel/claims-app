import {
  Component,
  Input,
  OnInit,
  OnChanges,
  SimpleChanges,
  Output,
  EventEmitter,
} from '@angular/core';
import { SortOptions } from '@usitsdasdesign/dds-ng/shared';
import { SearchOptions } from '@usitsdasdesign/dds-ng/search';
import { Column } from './column.model';

@Component({
  selector: 'cap-ui-listing',
  templateUrl: './listing.component.html',
  styleUrls: ['./listing.component.scss'],
})
export class ListingComponent implements OnInit, OnChanges {
  @Input() itemList: Array<any> = [];
  @Input() itemColumns: Column[] = [];
  @Input() heading = '';
  @Input() pageSize = 10;
  @Input() defaultSortingColumnNo = 0;

  @Output() columnClick: EventEmitter<any> = new EventEmitter();
  @Output() customAction: EventEmitter<any> = new EventEmitter();

  currentPageItems: Array<any> = [];
  currentPageSize: number;
  currentPageNumber: number;
  searchValue = '';
  searchOptions: SearchOptions = {
    placeholder: 'Search',
    isDisabled: false,
  };
  itemListCopy: Array<any> = [];

  public sortingState: SortOptions;

  constructor() {}

  /**
   *
   *
   * @param {SimpleChanges} simpleChanges
   * @memberof ListingComponent
   */
  ngOnChanges(simpleChanges: SimpleChanges): void {
    if (simpleChanges) {
      this.itemListCopy = [...simpleChanges.itemList.currentValue];
      if (
        Number(this.defaultSortingColumnNo) > -1 &&
        Number(this.defaultSortingColumnNo) <= this.itemColumns.length - 1
      ) {
        this.sortingState = {
          property: this.itemColumns[this.defaultSortingColumnNo].name,
          descending: false,
          dataType: this.itemColumns[this.defaultSortingColumnNo].dataType,
        };
      } else {
        console.error(
          `defaultSortingColumnNo should be greater than -1 and less than ${this.itemColumns.length}`
        );
      }
    }
  }

  ngOnInit(): void {}

  /**
   * On Page Change
   *
   * @param {*} pageinfo
   * @memberof ListingComponent
   */
  onPageChange(pageinfo): void {
    this.currentPageSize = pageinfo.pageSize;
    this.currentPageItems = pageinfo.pageItems;
    this.currentPageNumber = pageinfo.pageNumber;
  }

  /**
   * Sort table Column
   *
   * @param {Column} column
   * @memberof ListingComponent
   */
  public sortColumn(column: Column): void {
    if (this.sortingState && this.sortingState.property === column.name) {
      if (this.sortingState.descending) {
        this.sortingState = null;
      } else {
        this.sortingState.descending = true;
      }
    } else {
      this.sortingState = {
        property: column.name,
        descending: false,
        dataType: column.dataType,
      };
    }
  }

  /**
   * On Search
   *
   * @param {string} value
   * @memberof ListingComponent
   */
  onSearch(value: string): void {
    const temp = this.itemListCopy.filter((el) => {
      for (const key in el) {
        if (Object.prototype.hasOwnProperty.call(el, key)) {
          const element = el[key];
          if (element && element.length) {
            if (element.toLowerCase().includes(value.toLowerCase())) {
              return true;
            }
          }
        }
      }
    });
    this.itemList = temp;
  }

  /**
   * This method will call on click of every column, if isClickEnabled property is true
   *
   * @param {*} name
   * @param {*} rowData
   * @memberof ListingComponent
   */
  onColumnClick(name, rowData): void {
    this.columnClick.emit({ columnName: name, rowData });
  }

  /**
   * This method will call when any action button will be clicked
   *
   * @param {*} name
   * @param {*} rowData
   * @memberof ListingComponent
   */
  onActionClick(name, rowData): void {
    this.customAction.emit({ actionName: name, rowData });
  }
}
