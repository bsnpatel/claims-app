import { TableDataTypes } from '@usitsdasdesign/dds-ng/shared';

export interface Column {
  name: string;
  dataType: TableDataTypes | string;
  header?: string;
  minWidth?: string;
  maxWidth?: string;
  width?: string;
  sortable?: boolean;
  class?: string;
  isHTML?: boolean;
  actionType?: ActionColumn[];
  isClickEnabled?: boolean;
  htmlTemplate?: string;
}

interface ActionColumn {
  name: string;
  header: string;
  classNames: string;
  nestedItems: NestedActionItems[];
}

interface NestedActionItems {
  name: string;
  header: string;
  classNames: '';
}
