import {Injectable} from '@angular/core';
import {from, Observable, Subject,} from 'rxjs';
import {delay} from 'rxjs/operators';
@Injectable()
export class BoltDnDWidgetService {
    dom: Document;
    domSubject : Subject<Document>= new Subject<Document>();

    initialize(html: string) {
        const parser = new DOMParser();
		this.dom = parser.parseFromString(html, "text/xml");
    }

    asssignIdToNode(childNode: ChildNode) {
        if(childNode.nodeType == document.ELEMENT_NODE) {
                let element = childNode as Element
                if(!element.id) {
                    element.id =  element.tagName
                }
                childNode.replaceWith(element);
                
            }

            
    for (let i = 0; i < childNode.childNodes.length; i++) {
        let child = childNode.childNodes.item(i);
        //console.log(childNode + "->" + child.nodeName);
        if (child.nodeType == document.ELEMENT_NODE) {
            let element = child as Element
            if (element.parentElement.id) {
                if (childNode.childNodes.length > 1) {
                    element.id = element.parentElement.id + " [" + i + "]." + element.tagName
                } else {
                    element.id = element.parentElement.id + "." + element.tagName
                }
            } else {
                element.id = element.tagName
            }
            child.replaceWith(element);
        }

        childNode.replaceChild(this.asssignIdToNode(child), child);
    }
    //		});
    return childNode;
}

getTemplate(item) {
    var template;
    console.log("item.viewElement"+ item.viewElement)
    switch(item.viewElement) {
        case 'bolt.lang.Carousel': {
            template= `		<carousel slidesPerView="3" centeredSlides="false" index="3" showButtons="true" totalSlides="4">
				<div> Carousel Here </div
			
		</carousel>`
        break
        }
        case 'bolt.lang.SummaryColumn': {
            template= `
        <div>${item.name}</div>
        <div>${item.fieldLabel}</div>
        `
        break
        }

        case 'bolt.lang.ComponentViewElement': {
            template=  `
            <${item.name}></${item.name}>
            `
            break
        }
        case 'bolt.lang.Text': {
            template=  `<bolt-text name="${item.name}" label="${item.fieldLabel}"> Input </bolt-text>`
            break
        }
        case 'text': {
            template=  `<bolt-text name="${item.name}" label="${item.fieldLabel}"> Input </bolt-text>`
            break
        }
        case 'bolt.lang.DateField': {
            template=   `
   
    <mat-form-field [id]="${item.name}">
        <input matInput [matDatepicker]="picker"
            attr.aria-label="${item.fieldLabel}"
            placeholder="${item.fieldLabel}" 
            field-type="date">
        <mat-datepicker-toggle matSuffix [for]="picker">
        </mat-datepicker-toggle>
        <mat-datepicker #picker></mat-datepicker>
    </mat-form-field>
            `
            break
        }
        case 'bolt.lang.DropDown': {
            template=   `
            <bolt-dropdown name="${item.name}" fieldLabel="${item.fieldLabel}"> Dropdown </bolt-dropdown>
            `
            break
        }
        case 'bolt.lang.Radio': {
            template=    `
            <mat-radio-group role="radiogroup" aria-labelledby="label-item.name"
            aria-describedby="label-item.nameError" class="" id="${item.name}"
            color="primary"  name="${item.name}">
            <mat-radio-button class="radio-text-padding question-response-values"
                [value]="${item.fieldLabel}">
                ${item.fieldLabel}
            </mat-radio-button>
        </mat-radio-group>
            `
            break
        }
        case 'bolt.lang.Button': {
            template=   `
            <button id="${item.name}" mat-raised-button class="primary-button" >${item.fieldLabel}</button>
            `
            break
        }
        case 'bolt.lang.Layout': {
            template=   `
            <bolt-layout layoutType="${item.orientation}"> </bolt-layout>
            `
            break
        }
    }
    
    console.log("getTemplate template"+ template)
    return template;

}

processNodes(childNode: ChildNode) {
    if (childNode.nodeType == document.ELEMENT_NODE) {
        let element = childNode as Element;
        element.setAttribute("draggable","true")
        switch (childNode.nodeName) {
            case "bolt-layout": {
                if(this.showAddLayoutItem && (!childNode.hasChildNodes() ||  (childNode.hasChildNodes() && childNode.lastChild.textContent!=='+'))) {
                   
                    let col = document.createElement("bolt-layout-item")
                    let x=element.id ? element.id : "";
                    col.innerHTML=`<button #btnX (click)="addColumnByLayoutId('`+x+`')">+</button>`
                    childNode.appendChild(col)                  
                    
                }
                if(!this.showAddLayoutItem && (childNode.hasChildNodes() && childNode.lastChild.textContent=='+')) {
                   
                    childNode.removeChild(childNode.lastChild)                
                    
                }
                break;
            }
            case "bolt-page": {
                if(!childNode.hasChildNodes() ||  (childNode.hasChildNodes() && childNode.lastChild.textContent!=='+')) {
                    let col = document.createElement("bolt-layout-item")
                    let x=element.id ? element.id : "";
                    col.innerHTML=`<button #btnX (click)="addColumnByLayoutId('`+x+`')">+</button>`
                    childNode.appendChild(col)                  
                    
                }
                break;
            }
        }
        if(element.tagName.toLowerCase().startsWith("bolt")) {
            if(this.showBorder) {
                element.setAttribute("style","border: 3px dotted gray;padding: 10px ")
                } else { 
                    element.setAttribute("style"," ")
                }
        }
        
    }

    for (let i = 0; i < childNode.childNodes.length; i++) {
        let child = childNode.childNodes.item(i);
        childNode.replaceChild(this.processNodes(child), child);
    }

    return childNode;
}

showBorder: false;
showAddLayoutItem:false;
    assignIds() {
		let doc = this.dom.documentElement;

		doc.replaceWith(this.asssignIdToNode(doc));
		return doc;
    }
    
	processDom() {
		let doc = this.dom.documentElement;

		doc.replaceWith(this.processNodes(doc));
		return doc;
		//const serializer = new XMLSerializer();

		// const xmlStr = serializer.serializeToString(this.dom.documentElement)
		// return xmlStr;
	}
    setShowBorders(showBorder) {
this.showBorder=showBorder
this.refresh()
    }

    setShowAddLayoutItem(showAddLayoutItem) {
        this.showAddLayoutItem=showAddLayoutItem
    //    this.processDom();
        this.refresh()
            }
    add(id,data) {
 debugger
      //  var el = this.dom.documentElement.ownerDocument.createElement("div")
 
        var item=JSON.parse(data);
//        el.innerHTML = this.getTemplate(item)

const parser = new DOMParser();
var tempDom = parser.parseFromString(this.getTemplate(item), "text/xml");

      var el=  tempDom.documentElement
      // el.style.border="3px dotted gray"
        this.dom.getElementById(id).appendChild(el)

        console.log("dom "+ this.dom.documentElement.outerHTML)
        this.refresh();
    }

    move(id,originalElementId) {
       
              debugger
               var el=this.dom.getElementById(originalElementId)
               
            
             if((el.parentElement.tagName === "div" )) {
                    el.parentElement.parentElement.removeChild(el.parentElement);
             } else  {
                el.parentElement.removeChild(el)
             }
               this.dom.getElementById(id).appendChild(el)
               console.log("dom "+ this.dom.documentElement.outerHTML)
               this.refresh();
           }


    
    refresh() {
        //		 this.compileDir.compile();
                this.domSubject.next(this.dom);
                console.log("dom "+ this.dom.documentElement.outerHTML)
    }

}
