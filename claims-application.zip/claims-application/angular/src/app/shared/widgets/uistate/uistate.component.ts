import { Component, Input } from '@angular/core';


@Component({
  selector: 'bolt-uistate',
  templateUrl: './uistate.component.html',
  styleUrls: ['./uistate.component.scss']
})
export class UiStateComponent  {
 
    @Input()
    state: any;

}