import { Component, Input, OnChanges, SimpleChanges } from "@angular/core";
import { DndItem } from "../../model/dnditem";
import { DndItemService } from "./dnd-item.service";

@Component({
  selector: 'bolt-dragdrop-item',
  templateUrl: './dnd-item.component.html',
  styleUrls: ['./dnd-item.component.scss']
})
export class DragDropItemComponent implements OnChanges {
  ngOnChanges(changes: SimpleChanges): void {

  }
  @Input()
  item: DndItem;

  constructor(private service:DndItemService){

  }

  style(item: DndItem) {
    return this.service.style(item)
  }
  

  clazz(item: DndItem) {
    return this.service.clazz(item)
  }
}