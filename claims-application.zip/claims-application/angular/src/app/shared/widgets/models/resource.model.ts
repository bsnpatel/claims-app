export interface EditorResource {

	uri : string;
	language : string;
	code : string; 
}
