import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewEncapsulation } from '@angular/core';
import { listen, MessageConnection } from 'vscode-ws-jsonrpc';
import { MonacoLanguageClient, CloseAction, ErrorAction, MonacoServices, createConnection } from 'monaco-languageclient';

import ReconnectingWebSocket from 'reconnecting-websocket';
import { EditorResource } from '../models/resource.model';

@Component({
  selector: 'bolt-code-editor',
  templateUrl: './code-editor.component.html',
  styleUrls: ['./code-editor.component.scss'],
  encapsulation: ViewEncapsulation.None,
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class CodeEditorComponent implements OnInit{

  @Input()
  resource: EditorResource;

  @Output()
  resourceChange= new EventEmitter<EditorResource>();


  defaultResource: EditorResource = { uri: '', code: '', language: '' }

  constructor() {
  }

  onCodeChange($event){
    this.resourceChange.emit({...this.resource, code :$event})
  }

  ngOnInit(): void {
    this.resource = { ...this.defaultResource, ...this.resource };
  }

  monacoOnInit(editor) {
    // install Monaco language client services
    MonacoServices.install(editor);
    // create the web socket
    const url = this.createUrl();
    const webSocket = this.createWebSocket(url);
    webSocket.addEventListener('error', (event) => {
      console.log(event)
    });

    // listen when the web socket is opened
    listen({
      webSocket,
      onConnection: (connection: MessageConnection) => {
        // create and start the language client
        const languageClient = this.createLanguageClient(connection);
        const disposable = languageClient.start();
        connection.onClose(() => disposable.dispose());
      }
    });
  }

  public createUrl(): string {

        return 'ws://localhost:5007/';

    
  }

  public createLanguageClient(connection: MessageConnection): MonacoLanguageClient {
    return new MonacoLanguageClient({
      name: `SuperBOLT Language Client`,
      clientOptions: {
        // use a language id as a document selector
        documentSelector: ['sbs' ,'sml']
        ,
        // disable the default error handler
        errorHandler: {
          error: () => ErrorAction.Continue,
          closed: () => CloseAction.DoNotRestart
        }
      },
      // create a language client connection from the sbs RPC connection on demand
      connectionProvider: {
        get: (errorHandler, closeHandler) => {
          return Promise.resolve(createConnection(<any>connection, errorHandler, closeHandler));
        }
      }
    });
  }

  public createWebSocket(socketUrl: string): any {
    const socketOptions = {
      maxReconnectionDelay: 10000,
      minReconnectionDelay: 1000,
      reconnectionDelayGrowFactor: 1.3,
      connectionTimeout: 10000,
      maxRetries: 5,
      debug: false
    };
    return new ReconnectingWebSocket(socketUrl, [], socketOptions);
  }

}
