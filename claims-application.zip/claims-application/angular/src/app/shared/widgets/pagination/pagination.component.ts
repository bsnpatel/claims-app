import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter,
  OnChanges,
  SimpleChanges,
} from '@angular/core';
import { PaginationOptions, Mode } from '@usitsdasdesign/dds-ng/pagination';
import { Themes } from '@usitsdasdesign/dds-ng/shared';

@Component({
  selector: 'cap-ui-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss'],
})
export class PaginationComponent implements OnInit, OnChanges {
  /**
   * Items field value must be passed from parent component
   *
   * @type {Array<any>}
   * @memberof PaginationComponent
   */
  @Input() items: Array<any>;

  // Below fields are optional, if not getting value from parent then default value will be used
  @Input() initialPage = 1;
  @Input() pageSize = 10;
  @Input() maxPages = 5;
  @Input() isDisabled = false;

  /**
   * changePage is mandatory to call from parent component
   *
   * @memberof PaginationComponent
   */
  @Output() changePage = new EventEmitter<any>(true);

  options: PaginationOptions = {
    pageLength: 3,
    mode: Mode.text,
    pageNumberInSection: this.maxPages,
    size: 'sm',
    theme: Themes.green,
    isDisabled: this.isDisabled,
  };

  constructor() {}

  ngOnChanges(changes: SimpleChanges): void {
    // reset page if items array has changed
    if (changes.items.currentValue !== changes.items.previousValue) {
      this.setPage(this.initialPage);
    }
  }

  ngOnInit(): void {
    // set page if items array isn't empty
    if (this.items && this.items.length) {
      this.setPage(this.initialPage);
    }
  }

  setPage(page: number) {
    if (!isNaN(page)) {
      const totalPages = Math.ceil(this.items.length / this.pageSize);
      this.options.pageLength = totalPages;

      // get new page of items from items array
      let pageOfItems = [];

      if (page === 1) {
        pageOfItems = this.items.slice(0, this.pageSize * page);
      } else {
        pageOfItems = this.items.slice(
          this.pageSize * (page - 1),
          this.pageSize * page
        );
      }
      const pageInfo = {
        pageItems: pageOfItems,
        pageSize: this.pageSize,
        pageNumber: page,
      };
      // call change page function in parent component
      this.changePage.emit(pageInfo);
    }
  }
}
