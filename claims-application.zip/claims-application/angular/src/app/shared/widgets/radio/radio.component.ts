import { Component, Input, OnInit, AfterViewInit, ViewChild, SimpleChanges, SimpleChange, OnChanges } from '@angular/core';
import { FormBuilder, FormGroup,Validators,FormControl } from '@angular/forms';
import {Subscription, Observable} from "rxjs";
import { FieldComponent } from '../field/field';

@Component({
  selector: 'bolt-radio',
  templateUrl: './radio.component.html',
  styleUrls: ['./radio.component.scss']
})
export class RadioComponent extends FieldComponent {
    @Input()
    options: any;

    constructor(protected _formBuilder: FormBuilder) {
      super(_formBuilder);
    }
    
    getName(option){
    	return option.name
    }
    
    getValue(option){
    	return option.value
    }
}