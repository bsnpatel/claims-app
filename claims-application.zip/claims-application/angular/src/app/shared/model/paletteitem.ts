import * as uuid from 'uuid';

export class PaletteItem {
    name: string;
    id: string;
    icon: string;
    viewElement:string;
    fieldType:string;
    fieldLabel: string;
    orientation?: string;
    children?: any[];
    constructor(options: {
        name: string,
        icon: string
    }) {
        this.name = options.name;
        this.icon = options.icon;
        this.id = uuid.v4();
    }
}