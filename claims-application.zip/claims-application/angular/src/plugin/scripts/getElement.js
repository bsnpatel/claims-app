'use strict';

const getElement = function (e) {
  return {
    id: e.id,
    name: getName(e),
    type: getType(e),
    tag: e.tagName,
    formControlName: getFormControlName(e.formControlName),
    title: e.title,
    label: getLabel(e),
    value: getValue(e),
    path: getPathTo(e),
    xpath: getXPathTo(e),
    link: e.href,
    boltPageModel: getPageName(),
    text: getInnerText(e),
    innerText: getInnerText(e),
    className:getClassNames(e.classList),
    maxLength: getMaxLength(e)

  };

  
}

const getLabel  = function(e) {
  if(e.label && e.label.trim().length>0){
    return e.label
  } else {
    var x=document.getElementsByTagName("label")
    for(var i=0;i<x.length;i++) {
      if(e.getAttribute("formcontrolname") && x[i].getAttribute("for") === e.getAttribute("formControlName")) {
        return x[i].textContent;
      }
      if(e.name && x[i].getAttribute("for") === e.name) {
        return x[i].textContent;
      }
      if(e.id && x[i].getAttribute("for") === e.id) {
        return x[i].textContent;
      }
    }
  }
}
const getMaxLength = function(e) {
  if(e.maxlength){
    return e.maxlength
  }
}
const getType = function(e) {
  if(e.type){
    return e.type;
  } else {
    return e.tagName;
  }
}

const getVariable = function (){
var selectedText = getSelectedText().split("||");
if (selectedText[0]) {
	var json = {"VariableName":{"text":selectedText[0], "xpath":selectedText[1]}};
	return JSON.stringify(json, null, 2);
	}
}

const getSelectedText = function (e) {
var text = "";
	var xpath = "";
    if (typeof window.getSelection != "undefined" && window.getSelection().type == "Range" ) {
       text = window.getSelection().toString();
       xpath =  getXPathTo(window.getSelection().anchorNode.parentNode);
	   //alert(text2);
	   
    } else if (typeof document.selection != "undefined" && document.selection.type == "Text") {
        text = document.selection.createRange().text;
		xpath =  getXPathTo(document.selection.anchorNode.parentNode);
    }
	if(text != "" && xpath != "" && text != "\n")
    return text+"||"+xpath;
	else
	return "";
}

const getValue = function (element) {
  if (element.type != null && (element.type.toLowerCase() == 'radio' || element.type.toLowerCase() == 'checkbox')) {
	  if(element.value != null && element.value.trim() != "") return element.value;
	return getInnerText(element);
  }
  else if (element.tagName != null && (element.tagName.toLowerCase() === "mat-option" || element.tagName.toLowerCase() === "option")) {
	  if(element.value != null && element.value.trim() != "") return element.value;
	return getInnerText(element);
  }
  else if (element.value != null && element.value.trim() != "") return element.value;
  else null;
}

const getInnerText = function (element) {
  if (element.textContent != null && element.textContent.trim() != ""){
    return element.textContent.trim();
  }
  else return getInnerText(element.parentElement);
}
const getPageName = function () {

  let option = localStorage.getItem("pagaNameIdOption");
 
  if(!option)
  {
    console.log("Option is empty");
    return getPageNameByURL();
  }
 
      function normalizePageName(pageName)
      {
        if(!pageName) return getPageNameByURL();

        pageName = pageName.replace(/[\W_]+/g, "");
        pageName = pageName.charAt(0).toUpperCase() + pageName.substr(1);

        return pageName;
      }
  
  switch(option)
  {
      case 'XPath': return normalizePageName(getPageNameByXPath(localStorage.getItem('pageNameIDXPath'))); // Indiana
      case 'Regex': return normalizePageName(getPageNameByRegex(localStorage.getItem('pageNameIDRegex'))); // AMPS
      case 'Page Title': return normalizePageName(getPageNameByTitle()); // Indiana
      case 'Page Sequence': return normalizePageName(getPageNameBySequence());
      case 'Query Param' : return normalizePageName(getPageNameByQueryParam(localStorage.getItem('pageNameQueryParam')));
      default: return getPageNameByURL(); 
  }
}

const getPageNameByURL = function()
{
   //	console.log("Domain: "+document.domain);
  //console.log("URL: "+document.URL);
  var pageName;

  var url = document.URL.split("?")[0];
  //	console.log("URL 1: "+url);
  var firstIndex = url.indexOf('/', url.indexOf(document.domain));
  //
  //console.log("URL 2: " + url);

  if (firstIndex == -1) pageName = "Home";
  else {
    url = url.substr(firstIndex);

    //console.log("URL 3: "+url);
    if (url.length == 1) pageName = "Home";
    else {
      if (url.charAt(url.length - 1) == '/') url = url.substr(0, url.length - 2);

      //console.log("URL 4: "+url);
      var index = url.lastIndexOf('/');

      if (index == -1) pageName = "Home";
      else pageName = url.substr(index + 1);
    }
  }
  pageName = pageName.replace(/[\W_]+/g, "");
  pageName = pageName.charAt(0).toUpperCase() + pageName.substr(1);
  //console.log("pageName: "+pageName);
  return pageName;
}

const getPageNameByXPath = function(xpath)
{
    function getElementByXPath(xpath) {
      return new XPathEvaluator()
        .createExpression(xpath)
        .evaluate(document, XPathResult.FIRST_ORDERED_NODE_TYPE)
        .singleNodeValue
    }

    let ele = getElementByXPath(xpath);

    if(ele && ele.innerText)
        return ele.innerText;

    return "";
}

const getPageNameByRegex = function(url_regex)
{
  let substr=""
  try
  {
    const url = decodeURI(document.URL); // Decode URL
    substr = url.match(url_regex);
  }catch(err)
  {
    console.debug(err);
  }
  
  return substr;
}

const getPageNameBySequence = function()
{
    let counter = localStorage.getItem("counter");

    if(counter && counter != 0)
      return "PageSequence"+counter;

    return "";
}

const getPageNameByTitle = function()
{
    return getPageNameByXPath('//title'); 
}

const getPageNameByQueryParam = function(queryParamVal)
{
  const params = new URLSearchParams(window.location.search)
  if(params.get(queryParamVal) != null && params.get(queryParamVal) != "")
  {
    return params.get(queryParamVal);
  }
  else
    getPageNameByURL();
}

const getName = function (e) {
  var elementName = "";
  var innerText=getInnerText(e);
  if (innerText != null && innerText != "") innerText = innerText.replace(/[\W_]+/g, "");
  
  var formControlName = e.getAttribute!=null?e.getAttribute("formcontrolname"):null;
  if (e.name != null && e.name != "" && e.name != "#") elementName = e.name.replace(/[\W_]+/g, "");
  else if (formControlName != null && formControlName != "") elementName = e.tagName.replace(/[\W_]+/g, "") + "_" + formControlName.replace(/[\W_]+/g, "");
  else if (innerText != null && innerText != "") elementName = e.tagName.replace(/[\W_]+/g, "") + "_" + innerText.replace(/[\W_]+/g, "");
  else if (e.link != null && e.link != "") elementName = e.tagName.replace(/[\W_]+/g, "") + "_" + element.link.replace(/[\W_]+/g, "");
  else if (e.id != null && e.id != "") elementName = e.tagName.replace(/[\W_]+/g, "") + "_" + e.id.replace(/[\W_]+/g, "");
  
  else if (e.classList != null && e.classList.length > 0) elementName = e.tagName.replace(/[\W_]+/g, "") + getClassNames(e.classList).replace(/[\W_]+/g, "");
  else elementName = e.tagName.replace(/[\W_]+/g, "");
  if(e.tagName=='A' && elementName=="") elementName = "link"; /*{
	  var linkCounter = localStorage.getItem("linkCount");
	  
	  elementName = "link"+linkCounter;
	  linkCounter++;
	  localStorage.setItem("linkCount",linkCounter);
  }*/
  //elementName = elementName.replace(/[\W_]+/g, "");
  return elementName;
}


const getFormControlName = function (e) {
  var elementName = "";
  
  var formControlName = e.getAttribute!=null?e.getAttribute("formcontrolname"):null;
  if(e.tag === 'input' || e.tag === "select" || e.tag === "button" || e.tag === "mat-select") {
    if (e.name != null && e.name != "" && e.name != "#") elementName = e.name.replace(/[\W_]+/g, "");
    else if (formControlName != null && formControlName != "") elementName = e.tagName.replace(/[\W_]+/g, "") + "_" + formControlName.replace(/[\W_]+/g, "");
    else if (e.id != null && e.id != "") elementName = e.tagName.replace(/[\W_]+/g, "") + "_" + e.id.replace(/[\W_]+/g, "");
   
  }
  
  return elementName;
}



const getClassNames = function (classList) {
  var classNames = "";
  classList.forEach(className => classNames += "." + className);
  return classNames;
}


const getPathTo = function (element) {
  return "//" + getPageName() +"/" + getXPathTo(element);
}


const getXPathTo = function (element) {
    return "//" + getXPath(element);
}

const getXPath = function (element) {

  var formControlName = element.getAttribute!=null?element.getAttribute("formcontrolname"):null;

	let xpath = "";

  if (element.name && element.name !== '' && element.name !== '#')
    xpath = element.tagName + "[@name='" + element.name + "']";
  else if (formControlName && formControlName !== '')
    xpath =  element.tagName + "[@formcontrolname='" + formControlName + "']";
  else if(element.tag==='a' && element.link !== '') {
      xpath =  element.tagName + "[@href='"+ element.link +"'";
  }
  else if (element.innerText !== '')
    xpath =  element.tagName + "[contains(.,'" + element.innerText.replace(/[^A-Z0-9 ]+/ig, "") + "') or text()='" + element.innerText.replace(/\r?\n|\r/g,"") + "']";
  else if (element.id !== '')
    xpath =  element.tagName + "[@id='" + element.id + "']";
  else if (element.class !== '')
    xpath =  element.tagName + "[@class='" + element.class + "']";
  
  if(element.type == "radio"){
		if(element.value != "" || element.value != null) xpath = xpath + "[@value='????']";
		else xpath = "//label[@for="+xpath+"/@id][text()='????']";
	}
 if (xpath != "")return xpath;
 
  if (element === document.body)
    return element.tagName;

  var ix = 0;
  var siblings = element.parentNode.childNodes;
  for (var i = 0; i < siblings.length; i++) {
    var sibling = siblings[i];
    if (sibling === element)
      return getXPath(element.parentNode) + '/' + element.tagName + '[' + (ix + 1) + ']';
    if (sibling.nodeType === 1 && sibling.tagName === element.tagName)
      ix++;
  }
}
