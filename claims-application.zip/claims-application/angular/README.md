# Based on angular-monaco-languageclient (https://github.com/Louis-7/angular-monaco-languageclient.git)

Install dependencies:

`npm install`

## Run
Start client with `npm start`. 

## Development server

Run `npm run sandbox` for a dev server. Navigate to `https://localhost:4200/`. The app will automatically reload if you change any of the source files.

