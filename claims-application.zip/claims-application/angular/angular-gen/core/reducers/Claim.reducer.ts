import {createEntityAdapter, EntityAdapter, EntityState} from '@ngrx/entity';
import { deepCopy, extend } from 'src/app/shared/utils';
import {Claim} from '../models/Claim.model';
import {ClaimActions, ClaimActionTypes} from '../actions/Claim.actions';

export interface ClaimState extends EntityState<Claim> {
	// additional entities state properties
	uiState?: string;
	error?: any;
	selected?: Claim;
}

export const adapter: EntityAdapter<Claim> = createEntityAdapter<Claim>();

export const initialState: ClaimState = adapter.getInitialState({
	// additional entity state properties
	uiState: '',
	error: '',
	selected: {
	isDirty: false,
	id: null,
	memberId: null,
	memberFirstName: null,
	memberInitial: null,
	memberLastName: null,
	billTaxId: null,
	billNpi: null,
	renderingTaxId: null,
	renderingNpi: null,
	diagCd1: null,
	diagCd2: null,
	diagCd3: null,
	diagCd4: null,
	diagCd5: null,
	totalCharge: null,
	fromDate: null,
	thruDate: null,
	claimType: '',
	}
});

export function reducer(state = initialState, action: ClaimActions): ClaimState {
	switch (action.type) {
		case ClaimActionTypes.AddClaim: {
			return adapter.addOne(action.payload.claim, state);
		}

		case ClaimActionTypes.UpsertClaim: {
			return adapter.upsertOne(action.payload.claim, state);
		}

		case ClaimActionTypes.AddClaims: {
			return adapter.addMany(action.payload.claims, state);
		}

		case ClaimActionTypes.UpsertClaims: {
			return adapter.upsertMany(action.payload.claims, state);
		}

		case ClaimActionTypes.UpdateClaimUiState: {
			return {...state, uiState: action.payload.uiState, error:''};
		}

		case ClaimActionTypes.UpdateClaimSuccess: {
			return adapter.upsertOne(action.payload.claim, {
				...state,
				uiState: 'updated',
				error:'',
				selected: action.payload.claim
			});
		}

		case ClaimActionTypes.UpdateClaimFail: {
			return {...state, uiState: 'updatefailed',  error: action.payload};
		}

		case ClaimActionTypes.UpdateClaim: {
			return {...state, uiState: 'updating', error:''};
		}

		case ClaimActionTypes.LoadClaims: {
			return {...state, uiState: 'loading', error:''};
		}

		case ClaimActionTypes.LoadClaimsByParentId: {
			return {...state, uiState: 'loading', error:''};
		}

		case ClaimActionTypes.UpdateClaims: {
			return adapter.updateMany(action.payload.claims, state);
		}

		case ClaimActionTypes.DeleteClaimSuccess: {
			return adapter.removeOne(action.payload.id, {
				...state,
				uiState: 'deleted',
				error:'',
				selected: undefined
			});
		}

		case ClaimActionTypes.DeleteClaimFail: {
			return {...state, uiState: 'deletefailed',  error: action.payload};
		}

		case ClaimActionTypes.DeleteClaim: {
			return {...state, uiState: 'deleting', error:''};
		}

		case ClaimActionTypes.DeleteClaims: {
			return adapter.removeMany(action.payload.ids, state);
		}

		case ClaimActionTypes.AllClaimLoaded: {
			return adapter.addAll(action.payload.claims, {
				...state,
				uiState: 'loaded',
				error:'',
				selected: (state.selected === null || (state.selected !=null && (state.selected.id ===null || state.selected.id=== ''))) ?  action.payload.claims[0] : state.selected 
		
				
			});
		}

		case ClaimActionTypes.AllClaimByParentIdLoaded: {
			return adapter.addAll(action.payload.claims, {
				...state,
				uiState: 'loaded',
				error:'',
				selected: action.payload.claims[0]
			});
		}

		case ClaimActionTypes.ResetClaimErrorState:{
			return {...state, error: '', uiState: 'ready'};
		}

		case ClaimActionTypes.AllClaimLoadFailed: {
			return {...state, uiState: 'loadfailed', error: action.payload};
		}

		case ClaimActionTypes.AllClaimByParentIdLoadFailed: {
			return {...state, uiState: 'loadfailed', error: action.payload};
		}
				
		case ClaimActionTypes.ClaimLoaded: {
			return adapter.addOne(action.payload.claim, {
								...state,
								uiState: 'loaded',
								error:'',
								selected: action.payload.claim
							});
		}

		case ClaimActionTypes.ClearClaims: {
			return adapter.removeAll(state);
		}

		case ClaimActionTypes.ReloadClaim: {
			return {...initialState, selected: initialState.selected, uiState:'', error:''};
		}
		
		case ClaimActionTypes.ResetClaim: {
			return {...state, selected: initialState.selected, uiState:'ready', error:''};
		}

		
		case ClaimActionTypes.SelectClaim: {
			return {...state, selected: action.payload.claim};
		}

	   case ClaimActionTypes.SelectClaimById: {
	     return {...state, selected: state.entities[action.payload.id]};
	   }

		default: {
			return state;
		}
	}
}


export const {
	selectIds,
	selectEntities,
	selectAll,
	selectTotal,
} = adapter.getSelectors();
