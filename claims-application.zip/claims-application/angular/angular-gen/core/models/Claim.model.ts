
export interface Claim {
	isDirty: boolean;
	id : string;
	memberId : string;
	memberFirstName : string;
	memberInitial : string;
	memberLastName : string;
	billTaxId : number;
	billNpi : number;
	renderingTaxId : number;
	renderingNpi : number;
	diagCd1 : string;
	diagCd2 : string;
	diagCd3 : string;
	diagCd4 : string;
	diagCd5 : string;
	totalCharge : string;
	fromDate : string;
	thruDate : string;
	claimType : string;
}
