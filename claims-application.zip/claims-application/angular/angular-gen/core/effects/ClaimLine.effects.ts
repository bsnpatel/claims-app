import {Injectable} from '@angular/core';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {
	ClaimLineActionTypes,
	ClaimLineLoaded,
	AllClaimLineLoaded,
	LoadClaimLine,
	LoadClaimLines,
	LoadClaimLinesByParentId,
	AllClaimLineByParentIdLoaded,
	AllClaimLineByParentIdLoadFailed,
	UpdateClaimLine,
	UpdateClaimLineFail,
	UpdateClaimLineSuccess,
	DeleteClaimLine,
	DeleteClaimLineSuccess,
	DeleteClaimLineFail,
	AllClaimLineLoadFailed,
	NoAction
} from '../actions/ClaimLine.actions';
import {of} from 'rxjs';
import {filter, map, mergeMap, withLatestFrom} from 'rxjs/operators';
import {select, Store} from '@ngrx/store';

import {AppState} from 'src/app/reducers/index';
import {ClaimLineService} from '../services/ClaimLine.service';
			
import {loaded} from '../selectors/ClaimLine.selector';
import {catchError, switchMap} from 'rxjs/internal/operators';

@Injectable()
export class ClaimLineEffects {

	@Effect()
		loadClaimLine$ = this.actions$
			.pipe(
				ofType<LoadClaimLine>(ClaimLineActionTypes.LoadClaimLine),
				mergeMap(action => this.claimLineService.findClaimLineById(action.payload.claimLine)),
				map(claimLine => new ClaimLineLoaded({claimLine}))
			);

  @Effect()
  loadAllClaimLine$ = this.actions$
  	.pipe(
  		ofType<LoadClaimLines>(ClaimLineActionTypes.LoadClaimLines),
  		withLatestFrom(this.store.pipe(select(loaded))),
  		filter(([action, indicator]) => !indicator),
  		switchMap((action) => {
  			return this.claimLineService.findAllClaimLine()
  					.pipe(
  					map(info => new AllClaimLineLoaded({claimLines: info})),
  				catchError(error => of(new AllClaimLineLoadFailed(error)))
  				);
  	})
  );
  
  @Effect()
  loadAllClaimLineByParentId$ = this.actions$
  	.pipe(
  		ofType<LoadClaimLinesByParentId>(ClaimLineActionTypes.LoadClaimLinesByParentId),
  		withLatestFrom(this.store.pipe(select(loaded))),
  		filter(([action, indicator]) => !indicator),
  		switchMap((action) => {
  			return this.claimLineService.findAllClaimLineByParentId(action[0].payload.parentId)
  					.pipe(
  					map(info => new AllClaimLineByParentIdLoaded({claimLines: info})),
  				catchError(error => of(new AllClaimLineByParentIdLoadFailed(error)))
  				);
  	})
  );
@Effect()
	updateClaimLine$ = this.actions$
		.pipe(
			ofType<UpdateClaimLine>(ClaimLineActionTypes.UpdateClaimLine),
			switchMap((action) => {
				return this.claimLineService
					.saveClaimLine(action.payload.claimLine)
						.pipe(
						map(info => new UpdateClaimLineSuccess({claimLine: info})),
					catchError(error => of(new UpdateClaimLineFail(error)))
					);
		})
	);

	@Effect()
	deleteClaimLine$ = this.actions$
		.pipe(
			ofType<DeleteClaimLine>(ClaimLineActionTypes.DeleteClaimLine),
			switchMap((action) => {
				return this.claimLineService
					.deleteClaimLine(action.payload.id)
					.pipe(
						map(info => new DeleteClaimLineSuccess({ id: info.id })),
						catchError(error => of(new DeleteClaimLineFail(error)))
					);
			})
		);

	constructor(private actions$: Actions, private claimLineService: ClaimLineService,private store: Store<AppState>) {
	}
}
