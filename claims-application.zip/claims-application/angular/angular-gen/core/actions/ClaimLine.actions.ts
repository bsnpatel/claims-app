import {Action} from '@ngrx/store';
import {Update} from '@ngrx/entity';
import {ClaimLine} from '../models/ClaimLine.model';

export enum ClaimLineActionTypes {
	LoadClaimLines = '[ClaimLine] Load ClaimLines',
	LoadClaimLine = '[ClaimLine] Load ClaimLine',
	ClaimLineLoaded = '[ClaimLine]  ClaimLine Loaded',
	AllClaimLineLoaded = '[ClaimLine] All ClaimLines Loaded',
	AllClaimLineLoadFailed = '[ClaimLine] Load All ClaimLines Failed',
	LoadClaimLinesByParentId = '[ClaimLine] Load ClaimLines By ParentId',
	AllClaimLineByParentIdLoaded = '[ClaimLine] All ClaimLines By ParentId Loaded',
	AllClaimLineByParentIdLoadFailed = '[ClaimLine] Load All ClaimLines By ParentId Failed',
	UpdateClaimLineUiState = '[ClaimLine] Update ui state',
	AddClaimLine = '[ClaimLine] Add ClaimLine',
	UpsertClaimLine = '[ClaimLine] Upsert ClaimLine',
	AddClaimLines = '[ClaimLine] Add ClaimLines',
	UpsertClaimLines = '[ClaimLine] Upsert ClaimLines',
	UpdateClaimLine = '[ClaimLine] Update ClaimLine',
	UpdateClaimLineSuccess =   '[ClaimLine] Update ClaimLine Success',
	UpdateClaimLineFail =   '[ClaimLine] Update ClaimLine Fail',
	UpdateClaimLines = '[ClaimLine] Update ClaimLines',
	DeleteClaimLine = '[ClaimLine] Delete ClaimLine',
	DeleteClaimLineSuccess = '[ClaimLine] Delete ClaimLine Success',
	DeleteClaimLineFail = '[ClaimLine] Delete ClaimLine Fail',
	DeleteClaimLines = '[ClaimLine] Delete ClaimLines',
	ClearClaimLines = '[ClaimLine] Clear ClaimLines',
	ResetClaimLine = '[ClaimLine] Reset ClaimLine',
	ReloadClaimLine = '[ClaimLine] Reload ClaimLine',
	SelectClaimLine = '[ClaimLine] Select ClaimLine',
	SelectClaimLineById= '[ClaimLine] Select ClaimLine By Id',
	ResetClaimLineErrorState = '[ClaimLine] Reset ClaimLine Error State',
	NoAction = '[ClaimLine] No Action'
	
}

export class UpdateClaimLineUiState implements Action {
	readonly type = ClaimLineActionTypes.UpdateClaimLineUiState;
	constructor(public payload: { uiState: string }) {
	}
}

export class ClaimLineLoaded implements Action {
	readonly type = ClaimLineActionTypes.ClaimLineLoaded;
	constructor(public payload: { claimLine: ClaimLine }) {
	}
}

export class AllClaimLineLoaded implements Action {
	readonly type = ClaimLineActionTypes.AllClaimLineLoaded;
	constructor(public payload: { claimLines: ClaimLine[] }) {
	}
}

export class AllClaimLineLoadFailed implements Action {
	readonly type = ClaimLineActionTypes.AllClaimLineLoadFailed;
	constructor(public payload: { error: Error }) {
	}
}

export class AllClaimLineByParentIdLoaded implements Action {
	readonly type = ClaimLineActionTypes.AllClaimLineByParentIdLoaded;
	constructor(public payload: { claimLines: ClaimLine[] }) {
	}
}

export class AllClaimLineByParentIdLoadFailed implements Action {
	readonly type = ClaimLineActionTypes.AllClaimLineByParentIdLoadFailed;
	constructor(public payload: { error: Error }) {
	}
}				
export class LoadClaimLine implements Action {
	readonly type = ClaimLineActionTypes.LoadClaimLine;
	constructor(public payload: { claimLine: string }) {
	}
}

export class  ResetClaimLineErrorState implements Action {
	readonly type = ClaimLineActionTypes.ResetClaimLineErrorState;
	constructor() {
	}
}

export class LoadClaimLines implements Action {
	readonly type = ClaimLineActionTypes.LoadClaimLines;
	constructor() {
	}
}

export class LoadClaimLinesByParentId implements Action {
	readonly type = ClaimLineActionTypes.LoadClaimLinesByParentId;
	constructor(public payload: {parentId : string} ) {
	}
}

export class AddClaimLine implements Action {
	readonly type = ClaimLineActionTypes.AddClaimLine;
	constructor(public payload: { claimLine: ClaimLine}) {
	}
}

export class UpsertClaimLine implements Action {
	readonly type = ClaimLineActionTypes.UpsertClaimLine;
	constructor(public payload: { claimLine: ClaimLine}) {
	}
}

export class AddClaimLines implements Action {
	readonly type = ClaimLineActionTypes.AddClaimLines;

	constructor(public payload: { claimLines: ClaimLine[] }) {
	}
}

export class UpsertClaimLines implements Action {
	readonly type = ClaimLineActionTypes.UpsertClaimLines;
	constructor(public payload: { claimLines: ClaimLine[] }) {
	}
}


export class UpdateClaimLineSuccess implements Action {
	readonly type = ClaimLineActionTypes.UpdateClaimLineSuccess;
	constructor(public payload: { claimLine: ClaimLine }) {
	}
}
export class UpdateClaimLineFail implements Action {
	readonly type = ClaimLineActionTypes.UpdateClaimLineFail;
	constructor(public payload: { error: Error }) {
	}
}
export class UpdateClaimLine implements Action {
	readonly type = ClaimLineActionTypes.UpdateClaimLine;
	constructor(public payload: { claimLine: ClaimLine }) {
	}
}

export class UpdateClaimLines implements Action {
	readonly type = ClaimLineActionTypes.UpdateClaimLines;
	constructor(public payload: { claimLines: Update<ClaimLine>[] }) {
	}
}
				
export class DeleteClaimLineSuccess implements Action {
	readonly type = ClaimLineActionTypes.DeleteClaimLineSuccess;
	constructor(public payload: { id: string }) {
	}
}
export class DeleteClaimLineFail implements Action {
	readonly type = ClaimLineActionTypes.DeleteClaimLineFail;
	constructor(public payload: { error: Error }) {
	}
}

export class DeleteClaimLine implements Action {
	readonly type = ClaimLineActionTypes.DeleteClaimLine;
	constructor(public payload: { id: string }) {
	}
}

export class DeleteClaimLines implements Action {
	readonly type = ClaimLineActionTypes.DeleteClaimLines;
	constructor(public payload: { ids: string[] }) {
	}
}

export class ClearClaimLines implements Action {
	readonly type = ClaimLineActionTypes.ClearClaimLines;
}

export class ResetClaimLine implements Action {
	readonly type = ClaimLineActionTypes.ResetClaimLine;
}

export class SelectClaimLine implements Action {
	readonly type = ClaimLineActionTypes.SelectClaimLine;
	constructor(public payload: { claimLine: ClaimLine }) {
	}
}

export class ReloadClaimLine implements Action {
	readonly type = ClaimLineActionTypes.ReloadClaimLine;
}

export class SelectClaimLineById implements Action {
	readonly type = ClaimLineActionTypes.SelectClaimLineById;
	constructor(public payload: { id: string }) {
	}
}
export class NoAction implements Action {
	readonly type = ClaimLineActionTypes.NoAction;
  
	constructor() {
	}
}

	
export type ClaimLineActions =
	LoadClaimLines
	| LoadClaimLinesByParentId
	| AllClaimLineLoaded
	| AllClaimLineLoadFailed
	| AllClaimLineByParentIdLoaded
	| AllClaimLineByParentIdLoadFailed
	| ClaimLineLoaded
	| UpdateClaimLineUiState
	| AddClaimLine
	| UpsertClaimLine
	| AddClaimLines
	| UpsertClaimLines
	| UpdateClaimLine
	| UpdateClaimLineFail
	| UpdateClaimLineSuccess
	| UpdateClaimLines
	| DeleteClaimLine
	| DeleteClaimLineFail
	| DeleteClaimLineSuccess
	| DeleteClaimLines
	| ClearClaimLines
	| ResetClaimLine
	| ReloadClaimLine
	| SelectClaimLine
	| SelectClaimLineById
	| ResetClaimLineErrorState
	| NoAction
	;
