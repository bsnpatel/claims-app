import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {from, Observable} from 'rxjs';
import {delay} from 'rxjs/operators';
import {Claim} from '../models/Claim.model';
import { environment } from 'src/environments/environment';


@Injectable()
export class ClaimService {
	nextId =  1;
	temp: Claim = {
		isDirty: false,
		id: null,
		memberId: null,
		memberFirstName: null,
		memberInitial: null,
		memberLastName: null,
		billTaxId: null,
		billNpi: null,
		renderingTaxId: null,
		renderingNpi: null,
		billType: null,
		diagCd1: null,
		diagCd2: null,
		diagCd3: null,
		diagCd4: null,
		diagCd5: null,
		totalCharge: null,
		fromDate: null,
		thruDate: null,
		claimType: '',
		};

	constructor(private http: HttpClient) {
	}

	findClaimById(id: string): Observable<Claim> {
		//	return from([this.temp])
		//		.pipe(delay(500));

		// return of(fakeResponse).delay(5000);
		return this.http.get<Claim>(environment.apiEndpoint + `/api/claim/${id}`);
	}

	findAllClaim(): Observable<Claim[]> {
		//	return from([[this.temp]]).pipe(delay(500));

		// return this.http.get('/api/claim')
		// .pipe(
		// map(res => res['payload'])
		// );
		return this.http.get<Claim[]>(environment.apiEndpoint + `/api/claim`);
	}

	findAllClaimByParentId(parentId : string): Observable<Claim[]> {
	//	return from([[this.temp]]).pipe(delay(500));

		// return this.http.get('/api/claim')
		// .pipe(
		// map(res => res['payload'])
		// );
		return this.http.get<Claim[]>(environment.apiEndpoint + `/api/claims/${parentId}`);
	}				
	deleteClaim(id: string): Observable<Claim> {
	//return of<string>(id).pipe(delay(500));
	let headers = new HttpHeaders()
	.set('Content-Type', 'application/json')
	.set('Accept', 'application/json');
	return this.http.delete<Claim>(environment.apiEndpoint + `/api/claim/${id}`,{headers: headers});
	}				

	saveClaim(changes: Claim): Observable<Claim> {
		//	let obj: Claim = {...changes};
		//	if (obj.id === '') {
		//		this.nextId = this.nextId + 1;
		//		obj.id = string(this.nextId);
		//	}
		//	return from([obj]).pipe(delay(500));
		
		let headers = new HttpHeaders()
		.set('Content-Type', 'application/json')
		.set('Accept', 'application/json');
		let body = JSON.stringify({changes});
		return this.http.put<Claim>(environment.apiEndpoint + `/api/claim`,
		 body, {headers: headers});
	}
}
