import {createFeatureSelector, createSelector} from '@ngrx/store';
import * as fromClaimLine from '../reducers/ClaimLine.reducer';
import {ClaimLineState} from '../reducers/ClaimLine.reducer';

export const selectClaimLineState = createFeatureSelector<ClaimLineState>('claimLine');

export const selectClaimLineById = (id: string) => createSelector(
	selectClaimLineState,
	claimLineState => claimLineState.entities[id]
);


export const selectClaimLine = () => createSelector(
	selectClaimLineState,
	claimLineState => claimLineState.selected
);

export const selectAllClaimLine = createSelector(
	selectClaimLineState,
	fromClaimLine.selectAll
);

export const loaded = createSelector(
	selectClaimLineState,
	claimLineState => claimLineState.uiState === 'ready'
);
export const uiState = createSelector(
	selectClaimLineState,
	claimLineState => claimLineState.uiState
);
export const error = createSelector(
	selectClaimLineState,
	claimLineState => claimLineState.error
);

