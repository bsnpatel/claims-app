import {createFeatureSelector, createSelector} from '@ngrx/store';
import * as fromClaim from '../reducers/Claim.reducer';
import {ClaimState} from '../reducers/Claim.reducer';

export const selectClaimState = createFeatureSelector<ClaimState>('claim');

export const selectClaimById = (id: string) => createSelector(
	selectClaimState,
	claimState => claimState.entities[id]
);


export const selectClaim = () => createSelector(
	selectClaimState,
	claimState => claimState.selected
);

export const selectAllClaim = createSelector(
	selectClaimState,
	fromClaim.selectAll
);

export const loaded = createSelector(
	selectClaimState,
	claimState => claimState.uiState === 'ready'
);
export const uiState = createSelector(
	selectClaimState,
	claimState => claimState.uiState
);
export const error = createSelector(
	selectClaimState,
	claimState => claimState.error
);

