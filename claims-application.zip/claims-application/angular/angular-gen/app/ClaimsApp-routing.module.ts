import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';


import {HomePage} from 'angular-gen/feature/HomePage/HomePage.component';	


const ClaimsAppRoutes: Routes = [
{path: '', component: HomePage},
{path: 'home', component: HomePage},
{
	path: 'claims',
	loadChildren: 'angular-gen/feature/ClaimFlow.module#ClaimFlowModule',
},
	{path: '**', redirectTo: ''}
];

@NgModule({
	imports: [RouterModule.forRoot(ClaimsAppRoutes)],
	exports: [RouterModule]
})
export class ClaimsAppRoutingModule {
}
