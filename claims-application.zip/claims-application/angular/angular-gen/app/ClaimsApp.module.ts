import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';				
import {HomePage} from 'angular-gen/feature/HomePage/HomePage.component';				
import {ClaimsAppRoutingModule} from './ClaimsApp-routing.module';
import {ClaimsApp} from './ClaimsApp.component';


import {MaterialModule} from 'src/app/shared/material/material.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {StoreModule} from '@ngrx/store';
import {metaReducers, reducers} from 'src/app/reducers';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import {environment} from 'src/environments/environment';
import {RouterStateSerializer, StoreRouterConnectingModule} from '@ngrx/router-store';
import {EffectsModule} from '@ngrx/effects';
import {CustomSerializer} from 'src/app/shared/utils';
import {HttpClientModule} from '@angular/common/http';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {WidgetsModule} from 'src/app/shared/widgets/widgets.module';


@NgModule({
	declarations: [
		ClaimsApp,
		HomePage

		
	],
	imports: [
		BrowserModule,
		FormsModule,
		ReactiveFormsModule,
		MaterialModule.forRoot(),
		FlexLayoutModule,
		BrowserAnimationsModule,
		ClaimsAppRoutingModule,
		HttpClientModule,
		WidgetsModule,
		StoreModule.forRoot(reducers, {metaReducers}),
		!environment.production ? StoreDevtoolsModule.instrument() : [],
		EffectsModule.forRoot([]),
		StoreRouterConnectingModule.forRoot({stateKey: 'router'})
	],
	providers: [
		{provide: RouterStateSerializer, useClass: CustomSerializer},
	],
	bootstrap: [ClaimsApp]
})
export class ClaimsAppModule {
}
