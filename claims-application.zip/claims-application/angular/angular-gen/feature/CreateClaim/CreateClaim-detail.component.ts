import {
  Component, HostBinding, OnDestroy, OnInit, SimpleChanges, SimpleChange, ViewEncapsulation,
  ChangeDetectionStrategy, Input, EventEmitter, Output
	} from '@angular/core';
import { FormBuilder, FormGroup,Validators,FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import {View} from 'src/app/shared/fwk/view';
import {FormField} from 'src/app/shared/fwk/form-field';
import {Subscription, Observable} from "rxjs/index";
import {select, Store} from '@ngrx/store';
import {AppState} from 'src/app/reducers/index';		
import { deepCopy, extend } from 'src/app/shared/utils';
	import { Claim  } from 'angular-gen/core/models/Claim.model';

	@Component({
		selector: 'create-claim-detail',
		templateUrl: './CreateClaim-detail.component.html',
		styleUrls: ['./CreateClaim-detail.component.scss'],
		encapsulation: ViewEncapsulation.None,
		changeDetection: ChangeDetectionStrategy.OnPush
	})
	export class CreateClaimDetail extends View<Claim> implements OnInit {
		@Input()
		claimTypeOptions: FormField[];
		parentRef: string="updated";

		@Output()
		next = new EventEmitter();
				
		@Output()
		previous = new EventEmitter();
				

		@Input()
		error: any;

		constructor(protected _formBuilder: FormBuilder, private store: Store<AppState>) {
			super(_formBuilder);
			this.buildForm();
		}
		ngOnInit() {
			this.formErrors = {
				
			};
				
			this.validationMessages= {
				
			}
			this.checkFormStatus();
		}
			
		getModel(): Claim {
			var modified = deepCopy(this.model);
			extend(modified, this.form.value);
			modified.isDirty = true;
			return modified				
		}
		

		filterByParentId(componentValues: any[] ,parentId:any) {
			return componentValues.filter(it=>{
				if(it.id && parentId) {
					return (it.id as string).includes(parentId);
				} 
			});
		}
		onNext() {
			this.next.next({model: this.getModel()});
		}
				
		
		patchForm(change: SimpleChange) {
			const form = this.getForm();
			if (form && !form.dirty) {
				if (change.currentValue !== null && change.currentValue !== undefined){
					form.patchValue({

					});
				}
			}
		}

		buildForm() {
			if (!this.form) {
				this.form = this._formBuilder.group({

				});
			}
		}
	}
