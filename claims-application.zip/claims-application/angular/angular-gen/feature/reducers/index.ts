import {ActionReducerMap, MetaReducer} from '@ngrx/store';

import * as fromClaim from 'angular-gen/core/reducers/Claim.reducer';
import * as fromClaimLine from 'angular-gen/core/reducers/ClaimLine.reducer';
import {storeFreeze} from 'ngrx-store-freeze';
import {routerReducer} from '@ngrx/router-store';
import { createFeatureSelector } from '@ngrx/store';
import { createSelector } from '@ngrx/store';
import { ActionReducer } from '@ngrx/store';
import { Action } from '@ngrx/store';

export interface AppState {
	Claim : fromClaim.ClaimState ;
	ClaimLine : fromClaimLine.ClaimLineState ;
	
	
}

export const reducers = {
  	Claim : fromClaim.reducer ,
  	ClaimLine : fromClaimLine.reducer ,
};
export const metaReducers: MetaReducer<AppState>[] = [
    logger,
    resetRootState,
    logout
];

export function getMetaReducers() {
  return metaReducers;
}

export function logger(reducer: ActionReducer<AppState>): ActionReducer<AppState> {
  return function (state: AppState, action: Action): AppState {
    console.log('%c State', 'color: blue; font-weight: bold;', state);
    const str = '%c ' + action.type;

    console.log(str, 'color: blueviolet; font-weight: bold;', action);
    return reducer(state, action);
  };
}

export function resetRootState(reducer: ActionReducer<AppState>): ActionReducer<AppState> {
  return function (state: AppState, action: Action): AppState {
   
    return reducer(state, action);
  };
}

export function logout(reducer: ActionReducer<AppState>): ActionReducer<AppState> {
  return function (state: AppState, action: Action): AppState {
   
    return reducer(state, action);
  };
}
  
