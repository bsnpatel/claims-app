import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';

import {ClaimFlowComponent} from './ClaimFlow/ClaimFlowComponent.component';

import {ClaimSummary} from 'angular-gen/feature/ClaimSummary/ClaimSummary.component';				
import {CreateClaim} from 'angular-gen/feature/CreateClaim/CreateClaim.component';				
import {ClaimLineSummary} from 'angular-gen/feature/ClaimLineSummary/ClaimLineSummary.component';				
import {CreateLine} from 'angular-gen/feature/CreateLine/CreateLine.component';				

const ClaimFlowRoutes: Routes = [

	{
		path: '',
		component: ClaimFlowComponent,
		children: [
			{path: '', redirectTo: 'claimSummary' },
			{ path: 'claimSummary', 
				component: ClaimSummary },
			{ path: 'createClaim', 
				component: CreateClaim },
			{ path: 'claimLine', 
				component: ClaimLineSummary },
			{ path: 'createLine', 
				component: CreateLine }
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(ClaimFlowRoutes)],
	exports: [RouterModule]
})
export class ClaimFlowRoutingModule {
}
