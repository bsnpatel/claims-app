import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {EffectsModule} from '@ngrx/effects';
import {FlowModule} from 'src/app/shared/ng-flow/flow.module';
import {WidgetsModule} from 'src/app/shared/widgets/widgets.module';
import {MaterialModule} from 'src/app/shared/material/material.module';
import {FlexLayoutModule} from '@angular/flex-layout';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {RouterModule} from '@angular/router';
import {StoreModule} from '@ngrx/store';
import { SweetAlert2Module } from '@sweetalert2/ngx-sweetalert2';
import {ClaimFlowComponent} from './ClaimFlow/ClaimFlowComponent.component';
import {ClaimFlowRoutingModule} from './ClaimFlow-routing.module';
import {ClaimSummary} from 'angular-gen/feature/ClaimSummary/ClaimSummary.component';				
import {ClaimSummaryList} from 'angular-gen/feature/ClaimSummary/ClaimSummary-list.component';
import {CreateClaim} from 'angular-gen/feature/CreateClaim/CreateClaim.component';				
import {CreateClaimDetail} from 'angular-gen/feature/CreateClaim/CreateClaim-detail.component';
import {ClaimLineSummary} from 'angular-gen/feature/ClaimLineSummary/ClaimLineSummary.component';				
import {ClaimLineSummaryList} from 'angular-gen/feature/ClaimLineSummary/ClaimLineSummary-list.component';
import {CreateLine} from 'angular-gen/feature/CreateLine/CreateLine.component';				
import {CreateLineDetail} from 'angular-gen/feature/CreateLine/CreateLine-detail.component';
import * as fromClaim from 'angular-gen/core/reducers/Claim.reducer';
import {ClaimEffects} from 'angular-gen/core/effects/Claim.effects';
import {ClaimService} from 'angular-gen/core/services/Claim.service';
import * as fromClaimLine from 'angular-gen/core/reducers/ClaimLine.reducer';
import {ClaimLineEffects} from 'angular-gen/core/effects/ClaimLine.effects';
import {ClaimLineService} from 'angular-gen/core/services/ClaimLine.service';

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		MaterialModule,
		FlexLayoutModule,
		RouterModule,
		FlowModule, 
		WidgetsModule,
		SweetAlert2Module,
		ClaimFlowRoutingModule,
		EffectsModule.forFeature([ClaimEffects]),
		StoreModule.forFeature('claim', fromClaim.reducer),
		EffectsModule.forFeature([ClaimLineEffects]),
		StoreModule.forFeature('claimLine', fromClaimLine.reducer),
		
	],
	declarations: [
		ClaimSummary,
		ClaimSummaryList,
		CreateClaim,
		CreateClaimDetail,
		ClaimLineSummary,
		ClaimLineSummaryList,
		CreateLine,
		CreateLineDetail,
		ClaimFlowComponent
	],
	entryComponents:[
	],
	providers: [
		ClaimService,
		ClaimLineService
	]
})
export class ClaimFlowModule {
}
