import {
  Component, HostBinding, OnDestroy, OnInit, OnChanges, SimpleChanges, SimpleChange, ViewEncapsulation,
  ChangeDetectionStrategy, Input, EventEmitter, Output, ViewChild,
} from '@angular/core';
import { FormBuilder, FormGroup,Validators,FormControl } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import {AppState} from 'src/app/reducers/index';
import {View} from 'src/app/shared/fwk/view';
import {FormField} from 'src/app/shared/fwk/form-field';
import { DeleteDialog } from 'src/app/shared/widgets/delete-dialog/delete-dialog.component';
import {selectClaimLine,
selectAllClaimLine, 
 uiState, error} from 'angular-gen/core/selectors/ClaimLine.selector';
import {
	LoadClaimLines, 
	ResetClaimLine, 
	SelectClaimLine,
	UpdateClaimLine,
	DeleteClaimLine,
	UpdateClaimLineUiState,
	ResetClaimLineErrorState
} from 'angular-gen/core/actions/ClaimLine.actions';
import {ClaimLine} from 'angular-gen/core/models/ClaimLine.model';
import { Column } from 'src/app/shared/widgets/listing/column.model';
				
@Component({
	selector: 'claim-line-summary-list',
	templateUrl: './ClaimLineSummary-list.component.html',
	styleUrls: ['./ClaimLineSummary-list.component.scss'],
	encapsulation: ViewEncapsulation.None,
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class ClaimLineSummaryList  implements OnChanges {
	
	dataSource: MatTableDataSource<ClaimLine>= new MatTableDataSource<ClaimLine>([]);
	@ViewChild(MatPaginator,{static:false}) paginator: MatPaginator;
	@Input() model;
	@Input() error: any;
	@Input() uiState: string;
	@Input() displayedColumns: Column[];
	

	// List Actions
	@Output() selectAction = new EventEmitter();
	@Output() deleteAction = new EventEmitter();
	@Output() editAction = new EventEmitter();
	@Output() addAction = new EventEmitter();
	
	
	//Flow Events
	@Output()
	next = new EventEmitter();
	@Output()
	previous = new EventEmitter();
	


	constructor(public dialog: MatDialog) {

	}
	
	ngAfterViewInit(): void {
			this.dataSource.paginator = this.paginator;
		}

	ngOnChanges(changes: SimpleChanges): void {
		this.dataSource.data =this.model;
	}
	
	onColumnClick(data): void {
		console.log(`data - ${data}`);
		this.selectAction.emit(data.rowData);
	  }

	  onActionClick(details): void {
		console.log(`actionData - ${details}`);
		if (details.actionName.toLowerCase() === 'edit') {
			this.editAction.emit(details.rowData);
		} else if (details.actionName.toLowerCase() === 'delete') {
			this.openDialog(details.rowData);
		} 
	  }	

	deleteClicked(obj) {
	this.openDialog(obj);
	}

	editClicked(obj) {
	this.editAction.emit(obj);
	}

	addClicked() {
	this.addAction.emit();
	}

	selectClicked(obj) {
	this.selectAction.emit(obj)
	}

	onNext() {
		this.next.next();
	}

	onPrevious() {
		this.previous.next();
	}
	
	applyFilter(filterValue: string) {
		this.dataSource.filter = filterValue.trim();
	}
	

	openDialog(obj): void {
	const dialogRef = this.dialog.open(DeleteDialog, {
		data: {name: obj.name}
	});
	dialogRef.afterClosed().subscribe(result => {
		if (result === true){
			this.deleteAction.emit(obj);
		}
	});
	}

}
