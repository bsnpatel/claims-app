import {AfterViewInit, Component, OnInit} from '@angular/core';

import {Router, ActivatedRoute} from '@angular/router';
import {FlowContainer} from 'src/app/shared/ng-flow/flow-container';
import {FlowEvent, FlowState} from 'src/app/shared/ng-flow/flow-state';
import {Flow} from 'src/app/shared/ng-flow/flow';
import {Store} from '@ngrx/store';
import {AppState} from 'src/app/reducers/index';


@Component({
	selector: 'claim-flow',
	templateUrl: './ClaimFlow.component.html',
	styleUrls: ['./ClaimFlow.component.scss'],
})
export class ClaimFlowComponent extends FlowContainer implements OnInit, AfterViewInit {

	constructor(private store: Store<AppState>, protected router: Router, protected route:ActivatedRoute) {
		super(router, route);
	}

	initialize() {
		this.flow = new Flow({
				id: 'feature.ClaimFlow', name: 'CLAIM-FLOW',
				eventSourceUri: 'claims',
				states: [
					new FlowState({
					id: 'feature.ClaimSummary',
					name: 'claimSummary',
					eventSourceUri: 'claimSummary',
					isdefault: true
					}),
					new FlowState({
					id: 'feature.CreateClaim',
					name: 'createClaim',
					eventSourceUri: 'createClaim',
					}),
					new FlowState({
					id: 'feature.ClaimLineSummary',
					name: 'claimLine',
					eventSourceUri: 'claimLine',
					}),
					new FlowState({
					id: 'feature.CreateLine',
					name: 'createLine',
					eventSourceUri: 'createLine',
					})
				]
			})
		;
	}

	ngOnInit(): void {
	//  throw new Error('Method not implemented.');
	}

	performTransition($event: FlowEvent) {
		console.log('state: ' + $event.state.id + ' event: ' + $event.value);
		switch ($event.state.id) {
			case 'feature.ClaimSummary':
				if ($event.value === 'next') {
					this.router.navigate(['/home']);
				}
				if ($event.value === 'previous') {
					this.router.navigate(['/home']);
				}
				if ($event.value === 'add') {
					this.transitionTo('feature.CreateClaim');
				}
				if ($event.value === 'edit') {
					this.transitionTo('feature.CreateClaim');
				}
				break;
			case 'feature.CreateClaim':
				if ($event.value === 'next') {
					this.transitionTo('feature.ClaimLineSummary');
				}
				if ($event.value === 'previous') {
					this.transitionTo('feature.ClaimSummary');
				}
				if ($event.value === 'add') {
				}
				if ($event.value === 'edit') {
				}
				break;
			case 'feature.ClaimLineSummary':
				if ($event.value === 'next') {
					this.transitionTo('feature.ClaimSummary');
				}
				if ($event.value === 'previous') {
					this.transitionTo('feature.ClaimSummary');
				}
				if ($event.value === 'add') {
					this.transitionTo('feature.CreateLine');
				}
				if ($event.value === 'edit') {
					this.transitionTo('feature.CreateLine');
				}
				break;
			case 'feature.CreateLine':
				if ($event.value === 'next') {
					this.transitionTo('feature.ClaimLineSummary');
				}
				if ($event.value === 'previous') {
					this.transitionTo('feature.ClaimLineSummary');
				}
				if ($event.value === 'add') {
				}
				if ($event.value === 'edit') {
				}
				break;
			default:
		}
	}
}
